# Kit de ingesta · Sesiones 1.2 y 1.3

**Curso:** Pipelines de Datos y ETL con Python · BSG Institute

Este kit es el mismo código del laboratorio de Colab, pero organizado como lo tendrías en un proyecto real:
módulos, configuración en `config.yaml`, secretos en `.env`, logs en archivo y códigos de salida para el orquestador.
Es la base del caso integrador: en las siguientes sesiones le iremos agregando piezas.

## Estructura

```
kit_ingesta_1_2/
├── config.yaml            # rutas, fuentes, contratos, parámetros HTTP y base de datos
├── docker-compose.yml     # PostgreSQL (y MySQL opcional) para la sesión 1.3
├── .env.example           # plantilla de secretos (cópiala como .env)
├── requirements.txt
├── ingesta/
│   ├── logs.py            # logging estructurado en JSON
│   ├── cliente_http.py    # reintentos con backoff exponencial, jitter y Retry-After
│   ├── archivos.py        # contratos, landing zone, cuarentena y manifiesto
│   ├── apis.py            # catálogo (offset), tipo de cambio (rango) y pedidos (cursor + checkpoint)
│   ├── api_caprichosa.py  # servidor local que falla a propósito
│   ├── generar_datos.py   # archivos de proveedores con sus mañas
│   ├── cli.py             # punto de entrada
│   └── bd/                # sesión 1.3: base transaccional
│       ├── sql/           # esquema para PostgreSQL y MySQL
│       ├── simulador.py   # carga inicial y actividad de la tienda
│       ├── extraccion.py  # carga completa e incremental (watermark + lookback)
│       ├── destino.py     # warehouse DuckDB: reemplazo, upsert, borrados
│       ├── cdc_postgres.py# CDC leyendo el WAL (decodificación lógica)
│       ├── cdc_mysql.py   # CDC leyendo el binlog
│       └── reconciliar.py # ¿el destino dice lo mismo que el origen?
└── tests/
    └── test_cliente_http.py
```

## Preparación (una sola vez)

Necesitas Python 3.11 o superior.

**Windows (PowerShell)**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Ejecución

Abre **dos terminales** con el entorno virtual activado.

**Terminal 1:** levanta la API caprichosa y déjala corriendo.
```bash
python -m ingesta.api_caprichosa
```

**Terminal 2:** genera los archivos de proveedores y corre la ingesta.
```bash
python -m ingesta.generar_datos
python -m ingesta.cli
```

Sin internet, agrega `--offline` y el catálogo y el tipo de cambio se leerán de los espejos locales:
```bash
python -m ingesta.cli --offline
```

Para correr una sola fuente: `python -m ingesta.cli --fuente pedidos`

Revisa el código de salida:
- Windows: `echo $LASTEXITCODE`
- macOS o Linux: `echo $?`

`0` significa que todo salió bien y `1` que alguna fuente falló.

## Qué revisar al terminar

| Carpeta | Qué contiene |
|---|---|
| `landing/raw/` | Las respuestas y archivos **tal como llegaron** |
| `landing/bronze/` | Parquet con metadatos (`_fuente`, `_cargado_en`, `_run_id`…) particionado por `fecha_carga=` |
| `landing/_cuarentena/` | Filas que no cumplieron el contrato |
| `landing/_manifiesto.jsonl` | Qué se ingestó, cuándo y con qué hash |
| `landing/_logs/` | Un evento JSON por línea |

## Tarea

1. Corre la ingesta dos veces. En la segunda, ¿qué dice el log de los archivos de proveedores? ¿Por qué?
2. Escribe en `config.yaml` el contrato del proveedor **oriente** y vuelve a correr `--fuente proveedores`.
3. Levanta la API con `--tasa-error 0.5`, corre `--fuente pedidos` y detén la ingesta con Ctrl+C a la mitad.
   Vuelve a correrla: ¿desde qué página continuó? Busca el evento `reanudando_desde_checkpoint`.
4. Corre las pruebas: `python -m pytest -q`

## Reglas del kit

- **Nunca** subas `.env` al repositorio (ya está en `.gitignore`).
- Nada se edita a mano dentro de `landing/raw`: lo que llegó, llegó.
- Si algo falla, el log debe decir **qué**, **dónde** y **con qué datos**.

---

## Sesión 1.3 · Ingesta desde bases de datos

Necesitas **Docker Desktop** funcionando. Las contraseñas de la base salen del mismo `.env`
(si tu `.env` viene de la sesión 1.2, agrega las líneas nuevas de `.env.example`).

### 1. Levanta la base transaccional

```bash
docker compose up -d                     # PostgreSQL con wal_level=logical
# o, para practicar con MySQL y su binlog:
docker compose --profile mysql up -d     # y en config.yaml cambia bd.motor a mysql
```

### 2. Crea los datos y simula actividad

```bash
python -m ingesta.bd.simulador --sembrar      # esquema + 50 000 pedidos con 90 días de historia
python -m ingesta.bd.simulador --pasos 300    # altas, cambios de estado, cancelaciones y borrados
```

### 3. Extrae con los tres métodos y compara

```bash
python -m ingesta.cli --fuente bd_completa
python -m ingesta.cli --fuente bd_incremental
python -m ingesta.cli --fuente bd_cdc
python -m ingesta.bd.simulador --pasos 300
python -m ingesta.cli --fuente bd_incremental
python -m ingesta.cli --fuente bd_cdc
python -m ingesta.bd.reconciliar
```

El warehouse queda en `warehouse/tienda.duckdb`; el estado de cada método (watermark, posición del binlog) en `landing/_estado/`.

### Tarea de la sesión 1.3

1. Corre la secuencia anterior y explica, con la salida de `reconciliar`, por qué `pedidos_incremental` no cuadra.
2. Cambia `lookback_seg` a `0`. Abre una transacción larga en otra terminal
   (`docker compose exec postgres psql -U tienda -c "BEGIN; UPDATE pedidos SET estado='enviado' WHERE id=1000; SELECT pg_sleep(30); COMMIT;"`)
   y mientras corre, simula actividad y ejecuta `bd_incremental`. ¿Se perdió el cambio?
3. Haz lo mismo con MySQL (`--profile mysql`). ¿Qué cambia en el código? ¿Qué no cambia?
4. Al terminar: `docker compose down` (agrega `-v` para borrar también los datos).

> **Cuidado con los slots de replicación:** un slot de PostgreSQL que nadie consume retiene el WAL y puede llenar el disco.
> Si abandonas el ejercicio, bórralo: `docker compose exec postgres psql -U tienda -c "SELECT pg_drop_replication_slot('bsg_ingesta');"`
