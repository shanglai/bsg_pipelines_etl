import pandas as pd

from ingesta.bd.cdc_postgres import parsear_linea


def test_insert_con_comillas_nulos_y_fechas():
    linea = ("table public.pedidos: INSERT: id[bigint]:7 cliente_id[bigint]:3 estado[text]:'en tránsito ''urgente''' "
             "total[numeric]:1520.50 moneda[text]:null actualizado_en[timestamp with time zone]:'2026-10-01 18:00:00.5-06'")
    e = parsear_linea(linea)
    assert e["op"] == "INSERT" and e["tabla"] == "pedidos"
    assert e["fila"]["estado"] == "en tránsito 'urgente'"
    assert e["fila"]["total"] == 1520.50 and e["fila"]["moneda"] is None
    assert e["fila"]["actualizado_en"] == pd.Timestamp("2026-10-01 18:00:00.5-06")


def test_delete_trae_solo_la_llave():
    e = parsear_linea("table public.pedidos: DELETE: id[bigint]:42")
    assert e == {"tabla": "pedidos", "op": "DELETE", "fila": {"id": 42}}


def test_begin_y_commit_se_ignoran():
    assert parsear_linea("BEGIN 1234") is None and parsear_linea("COMMIT 1234") is None
