"""Destino analítico (DuckDB): cargas completas, upsert idempotente y aplicación de borrados."""
import duckdb
import pandas as pd

COLUMNAS = ["id", "cliente_id", "estado", "total", "moneda", "creado_en", "actualizado_en"]
DDL = """
CREATE TABLE IF NOT EXISTS {t} (
    id BIGINT PRIMARY KEY, cliente_id BIGINT, estado VARCHAR, total DOUBLE, moneda VARCHAR,
    creado_en TIMESTAMPTZ, actualizado_en TIMESTAMPTZ, _extraido_en TIMESTAMPTZ, _metodo VARCHAR
)"""


def abrir(ruta):
    return duckdb.connect(str(ruta))


def normalizar(df):
    """Tipos homogéneos sin importar si el origen fue PostgreSQL o MySQL."""
    df = df[COLUMNAS].copy()
    df["total"] = df["total"].astype(float)
    for col in ("creado_en", "actualizado_en"):
        df[col] = pd.to_datetime(df[col], utc=True)   # MySQL entrega DATETIME sin zona: la sesión está en UTC
    return df


def _preparar(con, tabla, df, metodo):
    con.execute(DDL.format(t=tabla))
    df = normalizar(df)
    df["_extraido_en"] = pd.Timestamp.now(tz="UTC")
    df["_metodo"] = metodo
    return df


def reemplazar(con, tabla, df, metodo):
    """Carga completa: borrar e insertar dentro de una transacción (nadie ve la tabla vacía)."""
    lote = _preparar(con, tabla, df, metodo)
    con.execute("BEGIN")
    con.execute(f"DELETE FROM {tabla}")
    con.execute(f"INSERT INTO {tabla} SELECT * FROM lote")
    con.execute("COMMIT")
    return len(lote)


def insertar_ingenuo(con, tabla, df, metodo):
    """Lo que NO hay que hacer: INSERT a secas en una tabla sin llave primaria
    (como en BigQuery o Redshift, que no hacen cumplir llaves). Cada corrida repetida duplica."""
    con.execute(DDL.format(t=tabla).replace(" PRIMARY KEY", ""))
    lote = normalizar(df)
    lote["_extraido_en"] = pd.Timestamp.now(tz="UTC")
    lote["_metodo"] = metodo
    con.execute(f"INSERT INTO {tabla} SELECT * FROM lote")
    return len(lote)


def upsert(con, tabla, df, metodo):
    """INSERT ... ON CONFLICT DO UPDATE: correrlo una o diez veces deja el mismo resultado."""
    if df.empty:
        return 0
    lote = _preparar(con, tabla, df, metodo).drop_duplicates(subset="id", keep="last")
    otras = [c for c in lote.columns if c != "id"]
    asignaciones = ", ".join(f"{c} = EXCLUDED.{c}" for c in otras)
    con.execute(f"INSERT INTO {tabla} SELECT * FROM lote ON CONFLICT (id) DO UPDATE SET {asignaciones}")
    return len(lote)


def borrar(con, tabla, ids):
    if ids:
        con.execute(DDL.format(t=tabla))
        con.execute(f"DELETE FROM {tabla} WHERE id IN (SELECT UNNEST(?))", [list(ids)])
    return len(ids)
