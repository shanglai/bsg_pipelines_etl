"""Reconciliación: ¿el destino dice lo mismo que el origen? La única forma honesta de saberlo es comparar."""
import pandas as pd
from sqlalchemy import text

from ..logs import evento


def reconciliar(engine, con, tabla_destino):
    with engine.connect() as c:
        origen = pd.read_sql(text("SELECT id, estado, total FROM pedidos"), c)
    origen["total"] = origen["total"].astype(float)
    dest = con.execute(f"SELECT id, estado, total FROM {tabla_destino}").df()
    cruce = origen.merge(dest, on="id", how="outer", suffixes=("_origen", "_destino"), indicator=True)
    ambos = cruce[cruce["_merge"] == "both"]
    resultado = {
        "destino": tabla_destino,
        "filas_origen": len(origen),
        "filas_destino": len(dest),
        "faltan_en_destino": int((cruce["_merge"] == "left_only").sum()),
        "sobran_en_destino": int((cruce["_merge"] == "right_only").sum()),
        "duplicados_en_destino": int(dest["id"].duplicated().sum()),
        "estado_distinto": int((ambos["estado_origen"] != ambos["estado_destino"]).sum()),
        "diferencia_total": round(dest["total"].sum() - origen["total"].sum(), 2),
    }
    resultado["cuadra"] = all(resultado[k] == 0 for k in ("faltan_en_destino", "sobran_en_destino",
                                                          "duplicados_en_destino", "estado_distinto"))
    evento("reconciliacion", **resultado)
    return resultado


if __name__ == "__main__":
    import argparse

    import yaml
    from dotenv import load_dotenv

    from .conexion import motor_desde_config
    from .destino import abrir

    p = argparse.ArgumentParser(description="Compara la base transaccional contra el warehouse")
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--tablas", nargs="+", default=["pedidos_completa", "pedidos_incremental", "pedidos_cdc"])
    a = p.parse_args()
    load_dotenv()
    with open(a.config, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    engine, con = motor_desde_config(cfg), abrir(cfg["warehouse"])
    existentes = {r[0] for r in con.execute("SELECT table_name FROM information_schema.tables").fetchall()}
    filas = [reconciliar(engine, con, t) for t in a.tablas if t in existentes]
    print(pd.DataFrame(filas).to_string(index=False) if filas else "No hay tablas que reconciliar todavía.")
