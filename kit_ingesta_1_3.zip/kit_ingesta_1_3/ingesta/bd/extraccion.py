"""Extracción desde la base transaccional: carga completa e incremental por marca de agua (watermark)."""
import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
from sqlalchemy import text

from ..archivos import escribir_atomico
from ..logs import evento
from . import destino

CONSULTA_COMPLETA = "SELECT id, cliente_id, estado, total, moneda, creado_en, actualizado_en FROM pedidos"
CONSULTA_INCREMENTAL = CONSULTA_COMPLETA + " WHERE actualizado_en > :desde ORDER BY actualizado_en, id"


def _guardar_raw(df, landing, metodo, fecha_carga):
    """Cada extracción queda en raw/ tal cual: si el destino se corrompe, se puede reconstruir."""
    marca = datetime.now(timezone.utc).strftime("%H%M%S%f")
    destino_raw = Path(landing) / "raw" / "bd" / "pedidos" / f"fecha_carga={fecha_carga}" / f"{metodo}_{marca}.parquet"
    escribir_atomico(destino_raw, lambda tmp: destino.normalizar(df).to_parquet(tmp, index=False))


def carga_completa(engine, con, tabla_destino, landing, fecha_carga):
    """Lee TODA la tabla y reemplaza el destino. Simple y exacta, pero cara: lee N filas cada vez."""
    inicio = time.perf_counter()
    with engine.connect() as c:
        df = pd.read_sql(text(CONSULTA_COMPLETA), c)
    _guardar_raw(df, landing, "completa", fecha_carga)
    destino.reemplazar(con, tabla_destino, df, "completa")
    stats = {"metodo": "completa", "filas_leidas": len(df), "segundos": round(time.perf_counter() - inicio, 2)}
    evento("bd_carga_completa", destino=tabla_destino, **stats)
    return stats


def _ruta_estado(landing, tabla_destino):
    return Path(landing) / "_estado" / f"watermark_{tabla_destino}.json"


def leer_watermark(landing, tabla_destino):
    ruta = _ruta_estado(landing, tabla_destino)
    if not ruta.exists():
        return None
    return datetime.fromisoformat(json.loads(ruta.read_text(encoding="utf-8"))["watermark"])


def carga_incremental(engine, con, tabla_destino, landing, fecha_carga, lookback_seg=300):
    """Trae solo lo que cambió desde la última marca de agua, menos una ventana de traslape (lookback).

    - La marca de agua sale de los DATOS (max(actualizado_en)), nunca del reloj de la máquina que extrae.
    - El lookback vuelve a leer los últimos minutos: atrapa transacciones que confirmaron tarde.
      Releer es seguro porque la carga es un upsert idempotente.
    - Limitación de fondo: los borrados físicos NO se ven (la fila ya no existe para consultarla).
    """
    inicio = time.perf_counter()
    marca = leer_watermark(landing, tabla_destino)
    if marca is None:
        desde = datetime(1970, 1, 1, tzinfo=timezone.utc)   # primera corrida: todo
    else:
        desde = marca - timedelta(seconds=lookback_seg)
    parametro = desde.astimezone(timezone.utc)
    if engine.dialect.name == "mysql":
        parametro = parametro.replace(tzinfo=None)   # DATETIME sin zona; la sesión trabaja en UTC
    with engine.connect() as c:
        df = pd.read_sql(text(CONSULTA_INCREMENTAL), c, params={"desde": parametro})
    if not df.empty:
        _guardar_raw(df, landing, "incremental", fecha_carga)
        destino.upsert(con, tabla_destino, df, "incremental")
        nueva = pd.to_datetime(df["actualizado_en"], utc=True).max().to_pydatetime()
        if marca is None or nueva > marca:
            # el estado se guarda DESPUÉS de cargar: si algo falla antes, la próxima corrida repite el lote
            escribir_atomico(_ruta_estado(landing, tabla_destino),
                             lambda tmp: Path(tmp).write_text(json.dumps({"watermark": nueva.isoformat()}), encoding="utf-8"))
            marca = nueva
    stats = {"metodo": "incremental", "lookback_seg": lookback_seg, "filas_leidas": len(df),
             "watermark": marca.isoformat() if marca else None, "segundos": round(time.perf_counter() - inicio, 2)}
    evento("bd_carga_incremental", destino=tabla_destino, **stats)
    return stats
