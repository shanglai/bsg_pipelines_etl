"""CDC basado en el log de MySQL (binlog), leyendo como si fuéramos una réplica.

Requisitos del servidor: binlog activo en formato ROW (valor por defecto en MySQL 8),
binlog_row_metadata = FULL (para recibir nombres de columna) y un usuario con
REPLICATION SLAVE y REPLICATION CLIENT. El docker-compose del kit ya lo configura.
"""
import json
import time
from pathlib import Path

import pandas as pd
from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import DeleteRowsEvent, UpdateRowsEvent, WriteRowsEvent
from sqlalchemy import text

from ..archivos import escribir_atomico
from ..logs import evento
from . import destino


def posicion_actual(engine):
    """Posición actual del binlog. MySQL 8.4 renombró el comando; soportamos ambos."""
    with engine.connect() as c:
        for consulta in ("SHOW BINARY LOG STATUS", "SHOW MASTER STATUS"):
            try:
                fila = c.execute(text(consulta)).mappings().first()
                return {"log_file": fila["File"], "log_pos": int(fila["Position"])}
            except Exception:
                continue
    raise RuntimeError("No se pudo leer la posición del binlog: ¿está activo y el usuario tiene REPLICATION CLIENT?")


def guardar_posicion(landing, posicion):
    ruta = Path(landing) / "_estado" / "binlog_posicion.json"
    escribir_atomico(ruta, lambda tmp: Path(tmp).write_text(json.dumps(posicion), encoding="utf-8"))


def leer_posicion(landing):
    ruta = Path(landing) / "_estado" / "binlog_posicion.json"
    return json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else None


def leer_y_aplicar(engine, con, tabla_destino, landing, ajustes_conexion, base, tabla_origen="pedidos", server_id=4242):
    """Lee el binlog desde la última posición guardada, aplica los cambios y guarda la nueva posición."""
    inicio = time.perf_counter()
    posicion = leer_posicion(landing)
    if posicion is None:
        raise RuntimeError("No hay posición inicial: toma primero la foto inicial con cdc_mysql.iniciar()")
    lector = BinLogStreamReader(connection_settings=ajustes_conexion, server_id=server_id, blocking=False,
                                resume_stream=True, log_file=posicion["log_file"], log_pos=posicion["log_pos"],
                                only_events=[WriteRowsEvent, UpdateRowsEvent, DeleteRowsEvent],
                                only_schemas=[base], only_tables=[tabla_origen])
    ultimo, eventos = {}, 0
    try:
        for ev in lector:
            for fila in ev.rows:
                if isinstance(ev, DeleteRowsEvent):
                    ultimo[fila["values"]["id"]] = ("DELETE", fila["values"])
                elif isinstance(ev, UpdateRowsEvent):
                    ultimo[fila["after_values"]["id"]] = ("UPDATE", fila["after_values"])
                else:
                    ultimo[fila["values"]["id"]] = ("INSERT", fila["values"])
                eventos += 1
        nueva = {"log_file": lector.log_file, "log_pos": lector.log_pos}
    finally:
        lector.close()
    upserts = [v for op, v in ultimo.values() if op != "DELETE"]
    borrados = [i for i, (op, _) in ultimo.items() if op == "DELETE"]
    if upserts:
        destino.upsert(con, tabla_destino, pd.DataFrame(upserts), "cdc")
    destino.borrar(con, tabla_destino, borrados)
    guardar_posicion(landing, nueva)   # después de aplicar: al-menos-una-vez
    stats = {"metodo": "cdc_binlog", "eventos": eventos, "upserts": len(upserts), "borrados": len(borrados),
             "posicion": nueva, "segundos": round(time.perf_counter() - inicio, 2)}
    evento("cdc_aplicado", destino=tabla_destino, **stats)
    return stats


def iniciar(engine, con, tabla_destino, landing, fecha_carga):
    """Foto inicial + posición del binlog. Se guarda la posición ANTES de la foto: lo que cambie durante
    la foto se volverá a aplicar después, y como la carga es idempotente, no pasa nada."""
    from .extraccion import carga_completa
    guardar_posicion(landing, posicion_actual(engine))
    return carga_completa(engine, con, tabla_destino, landing, fecha_carga)
