"""Simulador de la tienda en línea: genera actividad realista en la base transaccional.

Uso local:  python -m ingesta.bd.simulador --sembrar      (carga inicial)
            python -m ingesta.bd.simulador --pasos 300     (actividad: altas, cambios, cancelaciones, borrados)
"""
import argparse
import random
from datetime import datetime, timedelta, timezone

from sqlalchemy import text

SEMILLA = 987654
CIUDADES = ["CDMX", "Guadalajara", "Monterrey", "Puebla", "Lima", "Bogotá", "Santiago", "Querétaro", "Mérida", "Cusco"]
NOMBRES = ["Ana", "Luis", "María", "José", "Sofía", "Diego", "Valeria", "Jorge", "Camila", "Andrés", "Lucía", "Íñigo"]
APELLIDOS = ["García", "Hernández", "López", "Martínez", "Pérez", "Núñez", "Ramírez", "Torres", "Flores", "Peña"]
ESTADOS_SIGUIENTES = {"pagado": "enviado", "enviado": "entregado"}


def sembrar(engine, n_clientes=2000, n_pedidos=50000, semilla=SEMILLA):
    """Carga inicial reproducible. Borra lo que hubiera."""
    rng = random.Random(semilla)
    clientes = [{"nombre": f"{rng.choice(NOMBRES)} {rng.choice(APELLIDOS)}", "ciudad": rng.choice(CIUDADES)}
                for _ in range(n_clientes)]
    # Historia de 90 días: como en una base real, casi nada se modificó "hace un momento"
    ahora = datetime.now(timezone.utc)
    pedidos = []
    for _ in range(n_pedidos):
        creado = ahora - timedelta(days=rng.uniform(1, 90))
        actualizado = creado + timedelta(hours=rng.uniform(0, 72))
        if actualizado > ahora - timedelta(hours=1):
            actualizado = creado   # nunca se modificó
        if engine.dialect.name == "mysql":   # DATETIME sin zona: guardamos UTC
            creado, actualizado = creado.replace(tzinfo=None), actualizado.replace(tzinfo=None)
        pedidos.append({"cliente_id": rng.randint(1, n_clientes),
                        "estado": rng.choice(["pagado", "enviado", "entregado", "entregado", "entregado", "cancelado"]),
                        "total": round(rng.uniform(99, 25000), 2), "moneda": rng.choice(["MXN", "MXN", "MXN", "USD"]),
                        "creado_en": creado, "actualizado_en": actualizado})
    with engine.begin() as c:
        c.execute(text("DELETE FROM pedidos"))
        c.execute(text("DELETE FROM clientes"))
        if engine.dialect.name == "postgresql":
            c.execute(text("ALTER TABLE clientes ALTER COLUMN id RESTART WITH 1"))
            c.execute(text("ALTER TABLE pedidos ALTER COLUMN id RESTART WITH 1"))
        else:
            c.execute(text("ALTER TABLE clientes AUTO_INCREMENT = 1"))
            c.execute(text("ALTER TABLE pedidos AUTO_INCREMENT = 1"))
        c.execute(text("INSERT INTO clientes (nombre, ciudad) VALUES (:nombre, :ciudad)"), clientes)
        c.execute(text("INSERT INTO pedidos (cliente_id, estado, total, moneda, creado_en, actualizado_en) "
                       "VALUES (:cliente_id, :estado, :total, :moneda, :creado_en, :actualizado_en)"), pedidos)
    return {"clientes": n_clientes, "pedidos": n_pedidos}


def paso(engine, n_operaciones=100, semilla=None):
    """Actividad típica: 40 % altas, 45 % avance de estado, 10 % cancelaciones, 5 % borrados.
    Cada operación es su propia transacción, como en una aplicación real."""
    rng = random.Random(semilla)
    conteo = {"alta": 0, "avance": 0, "cancelacion": 0, "borrado": 0}
    with engine.connect() as c:
        max_id = c.execute(text("SELECT COALESCE(MAX(id), 0) FROM pedidos")).scalar()
        n_clientes = c.execute(text("SELECT COUNT(*) FROM clientes")).scalar()
    for _ in range(n_operaciones):
        dado = rng.random()
        objetivo = rng.randint(max(1, max_id - 5000), max(1, max_id))   # la actividad se concentra en pedidos recientes
        with engine.begin() as c:
            if dado < 0.40:
                c.execute(text("INSERT INTO pedidos (cliente_id, estado, total, moneda) VALUES (:c, 'pagado', :t, :m)"),
                          {"c": rng.randint(1, n_clientes), "t": round(rng.uniform(99, 25000), 2), "m": rng.choice(["MXN", "USD"])})
                conteo["alta"] += 1
            elif dado < 0.85:
                actual = c.execute(text("SELECT estado FROM pedidos WHERE id = :i"), {"i": objetivo}).scalar()
                if actual in ESTADOS_SIGUIENTES:
                    c.execute(text("UPDATE pedidos SET estado = :e WHERE id = :i"), {"e": ESTADOS_SIGUIENTES[actual], "i": objetivo})
                    conteo["avance"] += 1
            elif dado < 0.95:
                n = c.execute(text("UPDATE pedidos SET estado = 'cancelado' WHERE id = :i AND estado = 'pagado'"), {"i": objetivo}).rowcount
                conteo["cancelacion"] += n
            else:
                n = c.execute(text("DELETE FROM pedidos WHERE id = :i"), {"i": objetivo}).rowcount
                conteo["borrado"] += n
    return conteo


if __name__ == "__main__":
    import yaml
    from dotenv import load_dotenv

    from .conexion import crear_esquema, motor_desde_config

    p = argparse.ArgumentParser(description="Simulador de actividad de la tienda")
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--sembrar", action="store_true", help="crea el esquema y la carga inicial")
    p.add_argument("--pasos", type=int, default=0, help="número de operaciones a simular")
    a = p.parse_args()
    load_dotenv()
    with open(a.config, encoding="utf-8") as f:
        engine = motor_desde_config(yaml.safe_load(f))
    if a.sembrar:
        crear_esquema(engine)
        print("Carga inicial:", sembrar(engine))
    if a.pasos:
        print("Actividad simulada:", paso(engine, a.pasos))
