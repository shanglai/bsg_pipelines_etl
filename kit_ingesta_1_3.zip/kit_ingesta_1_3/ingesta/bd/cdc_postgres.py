"""CDC basado en el log de PostgreSQL (WAL) con decodificación lógica.

Usamos el plugin `test_decoding`, que viene incluido en PostgreSQL: no hay que instalar nada.
En producción se usa `pgoutput` (el de la replicación nativa) a través de Debezium o similares;
el principio es el mismo: leer el log de cambios en lugar de consultar las tablas.

Requisitos: wal_level = logical y un usuario con permiso de replicación.
"""
import re
import time

import pandas as pd
from sqlalchemy import text

from ..logs import evento
from . import destino

RE_LINEA = re.compile(r"^table (?P<esquema>[^.]+)\.(?P<tabla>[^:]+): (?P<op>INSERT|UPDATE|DELETE): (?P<resto>.*)$")
RE_COLUMNA = re.compile(r"(\w+)\[([^\]]+)\]:('(?:[^']|'')*'|\S+)")


def crear_slot(engine, slot="bsg_ingesta"):
    """El slot es el 'marcador' del consumidor: PostgreSQL guarda el WAL hasta que el slot lo confirme."""
    with engine.begin() as c:
        existe = c.execute(text("SELECT 1 FROM pg_replication_slots WHERE slot_name = :s"), {"s": slot}).scalar()
        if not existe:
            c.execute(text("SELECT pg_create_logical_replication_slot(:s, 'test_decoding')"), {"s": slot})
    evento("cdc_slot_listo", slot=slot, creado=not existe)
    return not existe


def borrar_slot(engine, slot="bsg_ingesta"):
    """Un slot abandonado retiene WAL para siempre y puede llenar el disco del servidor. Bórralo si ya no se usa."""
    with engine.begin() as c:
        c.execute(text("SELECT pg_drop_replication_slot(slot_name) FROM pg_replication_slots WHERE slot_name = :s"), {"s": slot})


def _valor(tipo, crudo):
    if crudo == "null":
        return None
    if crudo.startswith("'"):
        crudo = crudo[1:-1].replace("''", "'")
    if tipo in ("integer", "bigint", "smallint"):
        return int(crudo)
    if tipo.startswith("numeric") or tipo in ("double precision", "real"):
        return float(crudo)
    if tipo.startswith("timestamp"):
        return pd.Timestamp(crudo)
    return crudo


def parsear_linea(linea):
    """'table public.pedidos: UPDATE: id[bigint]:7 estado[text]:'enviado' ...' -> dict, o None si es BEGIN/COMMIT."""
    m = RE_LINEA.match(linea)
    if not m:
        return None
    fila = {col: _valor(tipo, crudo) for col, tipo, crudo in RE_COLUMNA.findall(m["resto"])}
    return {"tabla": m["tabla"], "op": m["op"], "fila": fila}


def leer_y_aplicar(engine, con, tabla_destino, slot="bsg_ingesta", tabla_origen="pedidos", max_cambios=50000):
    """Lee los cambios pendientes del slot SIN consumirlos (peek), los aplica al destino y solo entonces
    avanza el slot. Si falla a la mitad, los cambios siguen ahí: entrega al-menos-una-vez + aplicación idempotente."""
    inicio = time.perf_counter()
    with engine.connect() as c:
        filas = c.execute(text("SELECT lsn::text, xid::text, data FROM pg_logical_slot_peek_changes(:s, NULL, :n)"),
                          {"s": slot, "n": max_cambios}).all()
    eventos = [e for e in (parsear_linea(f.data) for f in filas) if e and e["tabla"] == tabla_origen]
    # Compactación: si un pedido cambió 3 veces en el lote, solo importa su último estado
    ultimo = {}
    for e in eventos:
        ultimo[e["fila"]["id"]] = e
    upserts = [e["fila"] for e in ultimo.values() if e["op"] != "DELETE"]
    borrados = [i for i, e in ultimo.items() if e["op"] == "DELETE"]
    if upserts:
        destino.upsert(con, tabla_destino, pd.DataFrame(upserts), "cdc")
    destino.borrar(con, tabla_destino, borrados)
    if filas:
        with engine.begin() as c:
            c.execute(text("SELECT pg_replication_slot_advance(:s, CAST(:lsn AS pg_lsn))"), {"s": slot, "lsn": filas[-1].lsn})
    conteo = pd.Series([e["op"] for e in eventos], dtype="object").value_counts().to_dict()
    stats = {"metodo": "cdc", "lineas_wal": len(filas), "eventos": len(eventos), "por_operacion": conteo,
             "upserts": len(upserts), "borrados": len(borrados), "segundos": round(time.perf_counter() - inicio, 2)}
    evento("cdc_aplicado", destino=tabla_destino, **stats)
    return stats
