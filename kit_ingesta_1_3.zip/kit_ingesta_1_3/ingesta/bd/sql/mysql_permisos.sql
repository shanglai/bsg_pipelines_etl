-- Solo para docker compose (se ejecuta como root): el usuario de ingesta puede leer el binlog
GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'tienda'@'%';
FLUSH PRIVILEGES;
