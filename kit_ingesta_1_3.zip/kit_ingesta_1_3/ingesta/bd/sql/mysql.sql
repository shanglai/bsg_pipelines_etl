-- Base transaccional de la tienda en línea (MySQL)
CREATE TABLE IF NOT EXISTS clientes (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(120) NOT NULL,
    ciudad         VARCHAR(60) NOT NULL,
    actualizado_en DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    cliente_id     BIGINT NOT NULL,
    estado         VARCHAR(20) NOT NULL,
    total          DECIMAL(12, 2) NOT NULL,
    moneda         VARCHAR(3) NOT NULL,
    creado_en      DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    actualizado_en DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    CONSTRAINT fk_pedidos_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    INDEX idx_pedidos_actualizado_en (actualizado_en, id)
);
