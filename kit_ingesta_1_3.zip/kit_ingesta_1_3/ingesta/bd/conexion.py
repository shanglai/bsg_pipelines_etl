"""Conexión a la base transaccional (PostgreSQL o MySQL) y creación del esquema."""
import os
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.engine import URL

SQL = Path(__file__).parent / "sql"
DRIVERS = {"postgresql": "postgresql+psycopg", "mysql": "mysql+pymysql"}


def crear_motor(motor, host, puerto, usuario, base, password=None, variable_password="BD_PASSWORD"):
    """La contraseña nunca va en la configuración: se lee de una variable de entorno."""
    password = password or os.environ.get(variable_password)
    if password is None:
        raise RuntimeError(f"Falta la variable de entorno {variable_password} (revisa tu .env)")
    url = URL.create(DRIVERS[motor], username=usuario, password=password, host=host, port=puerto, database=base)
    extra = {"connect_args": {"init_command": "SET time_zone = '+00:00'"}} if motor == "mysql" else {}
    return create_engine(url, pool_pre_ping=True, **extra)


def crear_esquema(engine):
    """Crea tablas, índice y trigger. En docker compose esto lo hace el contenedor al arrancar."""
    texto = (SQL / f"{engine.dialect.name}.sql").read_text(encoding="utf-8")
    with engine.begin() as c:
        if engine.dialect.name == "postgresql":
            c.exec_driver_sql(texto)   # psycopg acepta varias sentencias (y el $$ de la función)
        else:
            sin_comentarios = "\n".join(l for l in texto.splitlines() if not l.strip().startswith("--"))
            for sentencia in (s.strip() for s in sin_comentarios.split(";")):
                if sentencia:
                    c.exec_driver_sql(sentencia)


def motor_desde_config(cfg):
    """Arma el motor a partir de la sección `bd` de config.yaml."""
    bd = cfg["bd"]
    return crear_motor(bd["motor"], bd["host"], bd[bd["motor"]]["puerto"], bd["usuario"], bd["base"],
                       variable_password=bd["variable_password"])
