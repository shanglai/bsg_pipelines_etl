"""Ingesta desde la base transaccional: carga completa, incremental por watermark y CDC (sesión 1.3)."""
