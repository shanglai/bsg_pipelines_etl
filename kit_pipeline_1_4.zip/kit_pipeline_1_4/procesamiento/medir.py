"""Medición justa: cada motor corre en un proceso aparte para medir su tiempo y su memoria PICO sin
contaminar al resto (la memoria que un proceso libera no siempre se devuelve al sistema operativo).
La memoria se mide desde afuera, observando el proceso cada pocos milisegundos (funciona en Windows,
macOS y Linux).

Uso local:  python -m procesamiento.medir --carpeta datos_historial
"""
import argparse
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pandas as pd
import psutil

from .motores import FUERA_DE_MEMORIA, MOTORES

PLANTILLA = r"""
import json, sys, time
from procesamiento import motores
inicio = time.perf_counter()
resultado = getattr(motores, sys.argv[1])(sys.argv[2])
segundos = time.perf_counter() - inicio
resultado.to_parquet(sys.argv[3], index=False)
print(json.dumps({"segundos": round(segundos, 2)}))
"""


def medir(funcion, carpeta):
    """Corre motores.<funcion>(carpeta) en un proceso nuevo. Devuelve tiempo, memoria pico y el resultado."""
    with tempfile.TemporaryDirectory() as tmp:
        salida = Path(tmp) / "resultado.parquet"
        raiz = Path(__file__).resolve().parent.parent   # para que el subproceso encuentre el paquete
        p = subprocess.Popen([sys.executable, "-c", PLANTILLA, funcion, str(Path(carpeta).resolve()), str(salida)],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=raiz)
        proceso, pico = psutil.Process(p.pid), 0
        while p.poll() is None:   # observamos la memoria residente del hijo mientras trabaja
            try:
                pico = max(pico, proceso.memory_info().rss)
            except psutil.Error:
                break
            time.sleep(0.02)
        salida_std, error_std = p.communicate()
        if p.returncode != 0:
            return {"segundos": None, "pico_mb": None, "error": error_std.strip().splitlines()[-1][:160]}, None
        medicion = json.loads(salida_std.strip().splitlines()[-1])
        medicion["pico_mb"] = round(pico / 2**20)
        return medicion, pd.read_parquet(salida)


def comparar(carpeta, motores=None, repeticiones=1):
    """Tabla comparativa + verificación de que todos los motores dan el mismo resultado."""
    motores = motores or MOTORES
    base, _ = medir("base", carpeta)
    filas, referencia, iguales = [], None, {}
    for nombre, funcion in motores.items():
        mejores = None
        for _ in range(repeticiones):
            m, resultado = medir(funcion, carpeta)
            if mejores is None or (m["segundos"] is not None and m["segundos"] < mejores["segundos"]):
                mejores = m
        if resultado is not None:
            if referencia is None:
                referencia = resultado
            iguales[nombre] = bool(len(resultado) == len(referencia)
                                   and (resultado[["mes", "categoria", "ciudad", "unidades"]] == referencia[["mes", "categoria", "ciudad", "unidades"]]).all().all()
                                   and ((resultado["ingreso_mxn"] - referencia["ingreso_mxn"]).abs() < 0.05).all())
        filas.append({"motor": nombre, "segundos": mejores["segundos"],
                      "memoria_mb": None if mejores["pico_mb"] is None else mejores["pico_mb"] - base["pico_mb"],
                      "mismo_resultado": iguales.get(nombre), "error": mejores.get("error")})
    tabla = pd.DataFrame(filas).set_index("motor")
    if tabla["error"].isna().all():
        tabla = tabla.drop(columns="error")
    return tabla


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Compara motores de un solo nodo sobre el historial")
    p.add_argument("--carpeta", default="datos_historial")
    p.add_argument("--fuera-de-memoria", action="store_true", help="compara estrategias para datos que no caben en memoria")
    a = p.parse_args()
    print(comparar(a.carpeta, FUERA_DE_MEMORIA if a.fuera_de_memoria else MOTORES).to_string())
    print("\nmemoria_mb = memoria pico del proceso menos lo que ocupan Python y las librerías por sí solas")
