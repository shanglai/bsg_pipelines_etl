"""Del warehouse de la sesión 1.3 a un resumen con Polars: DuckDB entrega Arrow y Polars lo toma sin copiar.

Uso local:  python -m procesamiento.resumen_warehouse   (después de correr bd_cdc en la sesión 1.3)
"""
import argparse

import duckdb
import polars as pl


def resumen(ruta_warehouse, tabla="pedidos_cdc"):
    con = duckdb.connect(ruta_warehouse, read_only=True)
    try:
        pedidos = con.sql(f"SELECT estado, moneda, total, creado_en FROM {tabla}").pl()   # Arrow -> Polars
    finally:
        con.close()
    return (pedidos
            .with_columns(mes=pl.col("creado_en").dt.strftime("%Y-%m"))
            .group_by("mes", "estado", "moneda")
            .agg(pedidos=pl.len(), total=pl.col("total").sum().round(2))
            .sort("mes", "estado", "moneda"))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Resumen mensual de pedidos desde el warehouse")
    p.add_argument("--warehouse", default="warehouse/tienda.duckdb")
    p.add_argument("--tabla", default="pedidos_cdc")
    a = p.parse_args()
    with pl.Config(tbl_rows=40):
        print(resumen(a.warehouse, a.tabla))
