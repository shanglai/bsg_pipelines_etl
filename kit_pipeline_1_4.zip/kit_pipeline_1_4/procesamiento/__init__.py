"""Procesamiento en un solo nodo: pandas, Polars y DuckDB sobre el historial de la tienda (sesión 1.4)."""
