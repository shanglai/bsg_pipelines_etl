"""¿Qué fecha "es" cada corrida? Tres DAGs con el mismo horario y distinta configuración.

  reloj_disparo     schedule="0 6 * * *". En Airflow 3 es un disparo: la corrida del día D se crea a las 06:00 de D
                    y su logical_date es justo ese momento. El intervalo de datos mide cero.
  reloj_intervalo   CronDataIntervalTimetable: como en Airflow 2. La corrida del día D cubre de D 06:00 a D+1 06:00
                    y se crea al FINAL del intervalo, o sea, el día D+1.
  reloj_sin_catchup el mismo horario que reloj_disparo, pero catchup=False: no recupera el pasado.

Los tres empiezan el 8 de septiembre y terminan el 12, ya en el pasado: al despausarlos, Airflow decide qué
corridas crear. Compara cuántas creó cada uno y qué logical_date tiene cada corrida.
"""
import pendulum
from airflow.sdk import dag, task
from airflow.timetables.interval import CronDataIntervalTimetable

CDMX = pendulum.timezone("America/Mexico_City")
INICIO = pendulum.datetime(2026, 9, 8, 6, tz=CDMX)
FIN = pendulum.datetime(2026, 9, 12, 6, tz=CDMX)


@task
def mostrar(**contexto):
    def cdmx(t):
        return t.astimezone(CDMX).strftime("%Y-%m-%d %H:%M") if t else None

    run = contexto["dag_run"]
    print(f"logical_date={cdmx(contexto['logical_date'])}  ds={contexto['ds']}  "
          f"intervalo=[{cdmx(contexto['data_interval_start'])}, {cdmx(contexto['data_interval_end'])})  "
          f"run_after={cdmx(run.run_after)}  (horas de CDMX)")


@dag(schedule="0 6 * * *", start_date=INICIO, end_date=FIN, catchup=True, tags=["sesion_3_1"])
def reloj_disparo():
    mostrar()


@dag(schedule=CronDataIntervalTimetable("0 6 * * *", timezone=CDMX), start_date=INICIO, end_date=FIN, catchup=True,
     tags=["sesion_3_1"])
def reloj_intervalo():
    mostrar()


@dag(schedule="0 6 * * *", start_date=INICIO, end_date=FIN, catchup=False, tags=["sesion_3_1"])
def reloj_sin_catchup():
    mostrar()


reloj_disparo()
reloj_intervalo()
reloj_sin_catchup()
