"""La tienda, un día a la vez: el pipeline de la 2.2 orquestado por Airflow.

Cada corrida procesa UNA fecha de carga, la de su logical_date (`ds`), y nada más:

  revisar_<tabla> (x4, en paralelo)   ¿llegó la carga de ese día en las cuatro tablas de bronze?
  transformar                         python -m transformacion.pipeline --hasta <ds>  ->  lakehouse/corte=<ds>/
                                      (código de salida 2 = lote rechazado, 3 = falla de esquema: la tarea falla)
  publicar                            mueve el puntero lakehouse/vigente.txt a <ds>, pero nunca hacia atrás

Por qué así:
  - El resultado depende solo de <ds> y de bronze, nunca de "hoy": volver a correr un día da lo mismo (idempotente).
  - Cada día escribe su propia carpeta: reprocesar el 15 no pisa lo que ya publicó el 21.
  - El puntero solo avanza: un backfill del pasado no cambia lo que lee el tablero.
  - max_active_runs=1: un día a la vez y en orden.

La carga de la tienda se extrae a las 03:00 de CDMX; el DAG corre a las 06:00. Hay cargas del 08/09 al 21/09;
la del 22/09 todavía no llega (la agregamos en el laboratorio).
"""
import json
from pathlib import Path

import pendulum
from airflow.sdk import dag, task

KIT = Path(__file__).resolve().parents[2]
LAKEHOUSE = KIT / "lakehouse"
TABLAS = ["pedidos_web", "pedidos_tienda", "clientes", "tipo_cambio"]
CDMX = pendulum.timezone("America/Mexico_City")


@dag(schedule="0 6 * * *",
     start_date=pendulum.datetime(2026, 9, 8, 6, tz=CDMX),
     end_date=pendulum.datetime(2026, 9, 22, 6, tz=CDMX),
     catchup=True,
     max_active_runs=1,
     tags=["sesion_3_1", "tienda"],
     doc_md=__doc__)
def tienda_diaria():
    @task
    def revisar_carga(tabla: str, ds=None):
        carpeta = KIT / "landing" / "bronze" / tabla / f"fecha_carga={ds}"
        archivos = sorted(p.name for p in carpeta.glob("*.parquet"))
        if not archivos:
            raise FileNotFoundError(f"La carga del {ds} de {tabla} no ha llegado ({carpeta})")
        print(f"{tabla} {ds}: {archivos}")
        return len(archivos)

    @task.bash(cwd=str(KIT))
    def transformar(ds=None):
        # La tarea regresa el comando; Airflow lo corre y falla si el código de salida no es 0
        return (f"mkdir -p lakehouse/metricas && python -m transformacion.pipeline --landing landing "
                f"--salida lakehouse/corte={ds} --hasta {ds} --metricas lakehouse/metricas/{ds}.json")

    @task
    def publicar(ds=None):
        m = json.loads((LAKEHOUSE / "metricas" / f"{ds}.json").read_text(encoding="utf-8"))
        puntero = LAKEHOUSE / "vigente.txt"
        vigente = puntero.read_text(encoding="utf-8").strip() if puntero.exists() else ""
        if ds >= vigente:                      # las fechas AAAA-MM-DD se comparan bien como texto
            puntero.write_text(ds, encoding="utf-8")
            vigente = ds
        print(f"corte {ds}: {m['silver_pedidos']} pedidos en silver, {m['cuarentena']} en cuarentena, "
              f"huella de gold {m['huella_gold']}. Vigente: {vigente}")
        return {"corte": ds, "silver_pedidos": m["silver_pedidos"], "huella_gold": m["huella_gold"], "vigente": vigente}

    revisiones = [revisar_carga.override(task_id=f"revisar_{t}")(t) for t in TABLAS]
    revisiones >> transformar() >> publicar()


tienda_diaria()
