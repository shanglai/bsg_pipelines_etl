"""Las mismas cuatro tareas, en serie y en paralelo.

Cada tarea revisa una tabla de bronze de la tienda y tarda unos segundos (simulamos una fuente lenta).
En serie, el DAG tarda la suma; en paralelo, lo que tarda la más lenta (si hay lugares libres en el executor).
La tarea final solo corre cuando terminaron las cuatro: eso es un "fan-in".

Disparar:   airflow dags trigger en_serie   y   airflow dags trigger en_paralelo
"""
import time
from pathlib import Path

import pendulum
from airflow.sdk import chain, dag, task

KIT = Path(__file__).resolve().parents[2]
TABLAS = ["pedidos_web", "pedidos_tienda", "clientes", "tipo_cambio"]
CDMX = pendulum.timezone("America/Mexico_City")
SEGUNDOS = 4


@task
def revisar(tabla: str):
    import polars as pl

    time.sleep(SEGUNDOS)                       # la fuente lenta
    filas = pl.scan_parquet(KIT / "landing" / "bronze" / tabla / "**" / "*.parquet").select(pl.len()).collect().item()
    print(f"{tabla}: {filas} filas en bronze")
    return {"tabla": tabla, "filas": filas}


@task
def resumen(revisiones: list[dict]):
    for r in revisiones:
        print(f"{r['tabla']:>15}: {r['filas']:>7} filas")


@dag(schedule=None, start_date=pendulum.datetime(2026, 9, 1, tz=CDMX), catchup=False, tags=["sesion_3_1"])
def en_serie():
    revisiones = [revisar.override(task_id=f"revisar_{t}")(t) for t in TABLAS]
    chain(*revisiones)                         # pedidos_web >> pedidos_tienda >> clientes >> tipo_cambio
    resumen(revisiones)


@dag(schedule=None, start_date=pendulum.datetime(2026, 9, 1, tz=CDMX), catchup=False, tags=["sesion_3_1"])
def en_paralelo():
    revisiones = [revisar.override(task_id=f"revisar_{t}")(t) for t in TABLAS]
    resumen(revisiones)                        # sin dependencias entre ellas: pueden correr al mismo tiempo


en_serie()
en_paralelo()
