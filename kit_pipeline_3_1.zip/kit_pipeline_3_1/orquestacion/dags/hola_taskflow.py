"""Tu primer DAG con TaskFlow: tres funciones de Python que se pasan resultados.

Cada función decorada con @task es una tarea. Lo que una tarea regresa viaja a la siguiente como XCom
(Airflow lo guarda en su base de datos), por eso debe ser algo chico y serializable: un dict, una lista,
una ruta. Los datos grandes NUNCA viajan por XCom: se escriben en disco o en el lago y se pasa la ruta.

Probar sin scheduler:   airflow dags test hola_taskflow
"""
import pendulum
from airflow.sdk import dag, task

CDMX = pendulum.timezone("America/Mexico_City")


@dag(schedule=None, start_date=pendulum.datetime(2026, 9, 1, tz=CDMX), catchup=False, tags=["sesion_3_1"],
     doc_md=__doc__)
def hola_taskflow():
    @task
    def extraer():
        pedidos = [{"id": 1, "total": 250.0}, {"id": 2, "total": 99.5}, {"id": 3, "total": -10.0}]
        print(f"Extraje {len(pedidos)} pedidos")
        return pedidos

    @task
    def transformar(pedidos: list[dict]):
        validos = [p for p in pedidos if p["total"] > 0]
        print(f"{len(pedidos) - len(validos)} pedido(s) con total inválido")
        return {"validos": len(validos), "total": round(sum(p["total"] for p in validos), 2)}

    @task
    def cargar(resumen: dict):
        print(f"Cargaría {resumen['validos']} pedidos por {resumen['total']:.2f} MXN")

    # Llamar a las funciones NO las ejecuta: arma el grafo. extraer -> transformar -> cargar
    cargar(transformar(extraer()))


hola_taskflow()
