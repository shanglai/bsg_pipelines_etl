"""¿Cargan todos los DAGs? La primera prueba que corre cualquier equipo antes de subir un DAG.

Un error de sintaxis o un import que falla deja al DAG fuera del scheduler sin hacer ruido en tu terminal:
solo aparece en la UI como "import error". Esta prueba lo detecta antes.

  docker compose exec airflow python /opt/kit/orquestacion/revisar_dags.py
"""
import sys
from pathlib import Path

from airflow.dag_processing.dagbag import DagBag

bolsa = DagBag(dag_folder=str(Path(__file__).parent / "dags"))
for archivo, error in bolsa.import_errors.items():
    print(f"ERROR en {archivo}:\n{error}")
for dag_id, dag in sorted(bolsa.dags.items()):
    horario = dag.schedule if isinstance(dag.schedule, (str, type(None))) else type(dag.schedule).__name__
    print(f"ok  {dag_id:<18} {len(dag.tasks)} tareas  schedule={horario}")
sys.exit(1 if bolsa.import_errors else 0)
