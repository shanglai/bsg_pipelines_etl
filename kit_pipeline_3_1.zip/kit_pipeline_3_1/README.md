# Kit del pipeline · Sesiones 1.2 a 3.1

**Curso:** Pipelines de Datos y ETL con Python · BSG Institute

Este kit es el mismo código del laboratorio de Colab, pero organizado como lo tendrías en un proyecto real:
módulos, configuración en `config.yaml`, secretos en `.env`, logs en archivo y códigos de salida para el orquestador.
Es la base del caso integrador: en cada sesión le agregamos piezas. Desde la 1.4 se llama `kit_pipeline`, porque ya no solo ingesta: también procesa. En la 2.1 y la 2.2 se agrega la transformación de bronze a silver y gold; en la 2.3, la misma transformación dentro del motor con dbt; en la 3.1, Airflow la corre un día a la vez.

## Estructura

```
kit_pipeline_1_4/
├── config.yaml            # rutas, fuentes, contratos, parámetros HTTP y base de datos
├── docker-compose.yml     # PostgreSQL (y MySQL opcional) para la sesión 1.3
├── .env.example           # plantilla de secretos (cópiala como .env)
├── requirements.txt
├── ingesta/
│   ├── logs.py            # logging estructurado en JSON
│   ├── cliente_http.py    # reintentos con backoff exponencial, jitter y Retry-After
│   ├── archivos.py        # contratos, landing zone, cuarentena y manifiesto
│   ├── apis.py            # catálogo (offset), tipo de cambio (rango) y pedidos (cursor + checkpoint)
│   ├── api_caprichosa.py  # servidor local que falla a propósito
│   ├── generar_datos.py   # archivos de proveedores con sus mañas
│   ├── cli.py             # punto de entrada
│   └── bd/                # sesión 1.3: base transaccional
│       ├── sql/           # esquema para PostgreSQL y MySQL
│       ├── simulador.py   # carga inicial y actividad de la tienda
│       ├── extraccion.py  # carga completa e incremental (watermark + lookback)
│       ├── destino.py     # warehouse DuckDB: reemplazo, upsert, borrados
│       ├── cdc_postgres.py# CDC leyendo el WAL (decodificación lógica)
│       ├── cdc_mysql.py   # CDC leyendo el binlog
│       └── reconciliar.py # ¿el destino dice lo mismo que el origen?
├── procesamiento/         # sesión 1.4: un solo nodo
│   ├── generar_historial.py   # 10 millones de líneas de pedido (CSV, Parquet, particionado)
│   ├── motores.py             # la misma pregunta en pandas, Polars y DuckDB
│   ├── medir.py               # tiempo y memoria pico, cada motor en su propio proceso
│   ├── parquet_interno.py     # row groups, estadísticas min/max y saltos
│   └── resumen_warehouse.py   # del warehouse de la 1.3 a Polars vía Arrow
├── transformacion/        # sesiones 2.1 y 2.2: ETL en Python
│   ├── generar_bronze.py      # 14 días de cargas de la tienda, con sus mañas (y dos lotes rotos)
│   ├── leer.py                # la única parte que sabe dónde viven los archivos
│   ├── limpieza.py            # normalizar y conformar web + punto de venta al esquema de silver
│   ├── dedup.py               # última versión por llave de negocio, con desempate
│   ├── enriquecer.py          # tipo de cambio "as of" y cliente por punto en el tiempo
│   ├── scd.py                 # SCD tipo 1 y tipo 2 a partir de fotos diarias
│   ├── calidad.py             # contrato con Pandera, cuarentena y umbrales por carga
│   ├── gold.py                # agregados para el tablero
│   └── pipeline.py            # bronze -> silver -> gold, con falla cerrada y códigos de salida
├── elt/                   # sesión 2.3: ELT con dbt sobre DuckDB
│   ├── dbt_project.yml, profiles.yml
│   ├── seeds/                 # catálogos chicos: monedas, ciudades, estados del punto de venta
│   ├── models/staging/        # silver: una vista por fuente (bronze se lee directo de los Parquet)
│   ├── models/intermediate/   # silver: unir, deduplicar, cuarentena, tipo de cambio "as of"
│   ├── snapshots/             # SCD tipo 2 de clientes con dbt snapshot
│   ├── models/marts/          # gold: dimensiones, hechos y la tabla del tablero
│   ├── tests/                 # pruebas genéricas propias y reglas de lote (umbral y mediana por carga)
│   └── correr.py              # semillas + historia de clientes en orden + dbt build
├── tablero/app.py         # sesión 2.3: tablero en Streamlit sobre gold
├── orquestacion/          # sesión 3.1: Airflow 3
│   ├── compose.yaml, Dockerfile   # un contenedor con `airflow standalone`
│   ├── revisar_dags.py            # ¿cargan todos los DAGs?
│   └── dags/
│       ├── hola_taskflow.py       # el primer DAG: tres tareas y XCom
│       ├── serie_y_paralelo.py    # las mismas cuatro tareas, en serie y en paralelo
│       ├── reloj.py               # logical_date, intervalo de datos y catchup
│       └── tienda_diaria.py       # el pipeline de la 2.2, un día a la vez, con backfill seguro
└── tests/
```

## Preparación (una sola vez)

Necesitas Python 3.11 o superior.

**Windows (PowerShell)**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Ejecución

Abre **dos terminales** con el entorno virtual activado.

**Terminal 1:** levanta la API caprichosa y déjala corriendo.
```bash
python -m ingesta.api_caprichosa
```

**Terminal 2:** genera los archivos de proveedores y corre la ingesta.
```bash
python -m ingesta.generar_datos
python -m ingesta.cli
```

Sin internet, agrega `--offline` y el catálogo y el tipo de cambio se leerán de los espejos locales:
```bash
python -m ingesta.cli --offline
```

Para correr una sola fuente: `python -m ingesta.cli --fuente pedidos`

Revisa el código de salida:
- Windows: `echo $LASTEXITCODE`
- macOS o Linux: `echo $?`

`0` significa que todo salió bien y `1` que alguna fuente falló.

## Qué revisar al terminar

| Carpeta | Qué contiene |
|---|---|
| `landing/raw/` | Las respuestas y archivos **tal como llegaron** |
| `landing/bronze/` | Parquet con metadatos (`_fuente`, `_cargado_en`, `_run_id`…) particionado por `fecha_carga=` |
| `landing/_cuarentena/` | Filas que no cumplieron el contrato |
| `landing/_manifiesto.jsonl` | Qué se ingestó, cuándo y con qué hash |
| `landing/_logs/` | Un evento JSON por línea |

## Tarea

1. Corre la ingesta dos veces. En la segunda, ¿qué dice el log de los archivos de proveedores? ¿Por qué?
2. Escribe en `config.yaml` el contrato del proveedor **oriente** y vuelve a correr `--fuente proveedores`.
3. Levanta la API con `--tasa-error 0.5`, corre `--fuente pedidos` y detén la ingesta con Ctrl+C a la mitad.
   Vuelve a correrla: ¿desde qué página continuó? Busca el evento `reanudando_desde_checkpoint`.
4. Corre las pruebas: `python -m pytest -q`

## Reglas del kit

- **Nunca** subas `.env` al repositorio (ya está en `.gitignore`).
- Nada se edita a mano dentro de `landing/raw`: lo que llegó, llegó.
- Si algo falla, el log debe decir **qué**, **dónde** y **con qué datos**.

---

## Sesión 1.3 · Ingesta desde bases de datos

Necesitas **Docker Desktop** funcionando. Las contraseñas de la base salen del mismo `.env`
(si tu `.env` viene de la sesión 1.2, agrega las líneas nuevas de `.env.example`).

### 1. Levanta la base transaccional

```bash
docker compose up -d                     # PostgreSQL con wal_level=logical
# o, para practicar con MySQL y su binlog:
docker compose --profile mysql up -d     # y en config.yaml cambia bd.motor a mysql
```

### 2. Crea los datos y simula actividad

```bash
python -m ingesta.bd.simulador --sembrar      # esquema + 50 000 pedidos con 90 días de historia
python -m ingesta.bd.simulador --pasos 300    # altas, cambios de estado, cancelaciones y borrados
```

### 3. Extrae con los tres métodos y compara

```bash
python -m ingesta.cli --fuente bd_completa
python -m ingesta.cli --fuente bd_incremental
python -m ingesta.cli --fuente bd_cdc
python -m ingesta.bd.simulador --pasos 300
python -m ingesta.cli --fuente bd_incremental
python -m ingesta.cli --fuente bd_cdc
python -m ingesta.bd.reconciliar
```

El warehouse queda en `warehouse/tienda.duckdb`; el estado de cada método (watermark, posición del binlog) en `landing/_estado/`.

### Tarea de la sesión 1.3

1. Corre la secuencia anterior y explica, con la salida de `reconciliar`, por qué `pedidos_incremental` no cuadra.
2. Cambia `lookback_seg` a `0`. Abre una transacción larga en otra terminal
   (`docker compose exec postgres psql -U tienda -c "BEGIN; UPDATE pedidos SET estado='enviado' WHERE id=1000; SELECT pg_sleep(30); COMMIT;"`)
   y mientras corre, simula actividad y ejecuta `bd_incremental`. ¿Se perdió el cambio?
3. Haz lo mismo con MySQL (`--profile mysql`). ¿Qué cambia en el código? ¿Qué no cambia?
4. Al terminar: `docker compose down` (agrega `-v` para borrar también los datos).

> **Cuidado con los slots de replicación:** un slot de PostgreSQL que nadie consume retiene el WAL y puede llenar el disco.
> Si abandonas el ejercicio, bórralo: `docker compose exec postgres psql -U tienda -c "SELECT pg_drop_replication_slot('bsg_ingesta');"`

---

## Sesión 1.4 · Procesamiento en un solo nodo

No necesitas Docker para esta parte. Instala las dependencias nuevas: `pip install -r requirements.txt`.

### 1. Genera el historial

```bash
python -m procesamiento.generar_historial --filas 10000000    # ~1.2 GB en disco
# con 8 GB de RAM o menos:
python -m procesamiento.generar_historial --filas 3000000
```

### 2. Compara los motores

```bash
python -m procesamiento.medir                       # pandas, Polars y DuckDB sobre la misma pregunta
python -m procesamiento.medir --fuera-de-memoria    # estrategias cuando los datos no caben
```

Cada motor corre en su propio proceso para medir su **memoria pico** sin contaminar a los demás.
La columna `mismo_resultado` comprueba que todos responden exactamente lo mismo: un motor rápido que da otra respuesta no sirve.

### 3. Usa el warehouse de la 1.3

```bash
python -m procesamiento.resumen_warehouse     # requiere haber corrido bd_cdc de la sesión 1.3
```

### Tarea de la sesión 1.4

1. Corre `medir` en tu máquina y compara tus números con los de Colab. ¿Qué cambió y por qué?
2. En `motores.py`, agrega una función con la pregunta «top 10 productos por ingreso en CDMX en 2025»
   en el motor que prefieras, y verifica contra otro motor que el resultado sea el mismo.
3. Corre `python -m pytest -q`: las pruebas comprueban que todos los motores coinciden.
4. Al terminar, borra `datos_historial/`: ocupa más de 1 GB.

---

## Sesiones 2.1 y 2.2 · ETL en Python

No necesitas Docker. Instala las dependencias nuevas: `pip install -r requirements.txt`.

### 1. Genera bronze

```bash
python -m transformacion.generar_bronze --landing landing     # 14 cargas, del 08/09 al 21/09/2026
```

### 2. Corre el pipeline

```bash
python -m transformacion.pipeline --landing landing --salida lakehouse
```

Queda en `lakehouse/`:

| Carpeta | Qué contiene |
|---|---|
| `silver/pedidos.parquet` | Un pedido por llave `(origen, pedido_id)`, limpio, validado y en pesos |
| `silver/dim_cliente_historia.parquet` | SCD tipo 2: una fila por versión del cliente |
| `silver/dim_cliente.parquet` | La versión vigente de cada cliente |
| `silver/tipo_cambio.parquet` | Una tasa por día hábil |
| `gold/ventas_diarias.parquet` | Ventas por día de negocio, ciudad y canal |
| `_cuarentena/pedidos.parquet` | Lo que no cumplió el contrato, con su motivo |

Códigos de salida: `0` bien, `2` lote rechazado por calidad, `3` falla de esquema. Si algo falla, **no se publica nada**.

### 3. Rompe el origen a propósito

```bash
python -m transformacion.generar_bronze --landing landing --lote-malo ruidoso
python -m transformacion.pipeline --landing landing --salida lakehouse     # debe terminar con código 2
python -m transformacion.generar_bronze --landing landing --lote-malo silencioso
python -m transformacion.pipeline --landing landing --salida lakehouse     # también 2, pero por otra regla
```

### Tarea de las sesiones 2.1 y 2.2

1. Corre el pipeline dos veces y compara `huella_gold`. ¿Por qué es la misma?
2. Agrega a `limpieza.py` el estado `devuelto` (con su variante `DEVOLUCION` del punto de venta) y escribe su prueba **antes** de tocar el código.
3. En `calidad.py`, agrega una regla: un pedido de la tienda física no puede tener canal distinto de `tienda`.
4. ¿Qué pasa si corres `--hasta 2026-09-15` y después sin `--hasta`? ¿Cambia la historia de los clientes?
5. Corre `python -m pytest -q tests/test_transformacion.py`.

---

## Sesión 2.3 · ELT con dbt

Instala las dependencias nuevas: `pip install -r requirements.txt` (trae `dbt-core`, `dbt-duckdb` y `streamlit`).

### 1. Genera bronze (si no lo tienes de la 2.2)

```bash
python -m transformacion.generar_bronze --landing landing
```

### 2. Corre el proyecto dbt

```bash
python elt/correr.py              # semillas, las 14 fotos de clientes en orden y dbt build (menos de un minuto)
```

O paso a paso, desde la carpeta `elt/`:

```bash
cd elt
dbt seed --profiles-dir .
dbt build --profiles-dir . --select staging          # solo una capa
dbt build --profiles-dir .                           # todo: modelos, snapshot y pruebas en orden
dbt test --profiles-dir . --select test_type:unit    # solo las pruebas unitarias
dbt docs generate --profiles-dir . && dbt docs serve --profiles-dir .   # el linaje en el navegador
```

La base queda en `elt/tienda.duckdb` con tres esquemas: `silver`, `gold` y `referencia`.

### 3. Abre el tablero

```bash
streamlit run tablero/app.py
```

### 4. Rompe el origen y mira cómo se detiene

```bash
python -m transformacion.generar_bronze --landing landing --lote-malo ruidoso
python elt/correr.py --solo-build     # falla assert_rechazo_por_carga; gold no se toca (dbt salta lo que sigue)
```

### Tarea de la sesión 2.3

1. Agrega un modelo de gold `mart_cancelaciones` (cancelaciones por día y canal) con su prueba de `not_null`.
2. Escribe una prueba unitaria de dbt para `stg_pedidos_tienda`: una venta de las 21:30 debe quedar con fecha de negocio del mismo día.
3. Corre `python -m pytest -q tests/test_elt.py`: compara el ETL en Python (2.1 y 2.2) contra el ELT en dbt. ¿Dan lo mismo?
4. ¿Qué pasa si corres el snapshot con la foto del 10/09 después de la del 21/09? Compáralo con `FotoFueraDeOrden` de la 2.2.

---

## Sesión 3.1 · Fundamentos de Apache Airflow

Airflow **no corre directo en Windows**: lo levantamos en Docker (o en WSL2). Necesitas Docker Desktop y unos 2 GB de
RAM libres. La primera vez descarga la imagen oficial (~1.1 GB).

### 1. Genera bronze (si no lo tienes de la 2.2)

```bash
python -m transformacion.generar_bronze --landing landing      # las 14 cargas, del 08/09 al 21/09
```

### 2. Levanta Airflow

```bash
cd orquestacion
docker compose up -d --build
docker compose ps                         # espera a que diga "healthy" (1 a 2 minutos)
docker compose exec airflow python /opt/kit/orquestacion/revisar_dags.py
```

Abre http://localhost:8080 (sin contraseña). Todos los DAGs nacen **pausados**.

En Linux (no en Docker Desktop), el contenedor escribe en tu carpeta del kit con otro usuario. Levántalo con tu
usuario para no tener problemas de permisos: `AIRFLOW_UID=$(id -u) docker compose up -d --build`.

### 3. Los DAGs de la sesión

Desde la UI (el interruptor de cada DAG y el botón *Trigger*) o desde la terminal:

```bash
docker compose exec airflow airflow dags test hola_taskflow           # una corrida, sin scheduler, en tu terminal
docker compose exec airflow airflow dags unpause en_serie
docker compose exec airflow airflow dags trigger en_serie
docker compose exec airflow airflow dags unpause en_paralelo
docker compose exec airflow airflow dags trigger en_paralelo           # compara las duraciones en la vista Grid
docker compose exec airflow airflow dags unpause reloj_disparo         # y reloj_intervalo, reloj_sin_catchup
```

### 4. La tienda, un día a la vez

```bash
docker compose exec airflow airflow dags unpause tienda_diaria
```

Con `catchup=True` crea 15 corridas, del 08/09 al 22/09, una a la vez. Las 14 primeras terminan bien; la del 22 falla
porque esa carga todavía no llega. Cada día queda en `lakehouse/corte=AAAA-MM-DD/` y el puntero `lakehouse/vigente.txt`
dice cuál es el último corte publicado.

Llega la carga del 22 (con datos rotos) y la reintentas:

```bash
cd ..
python -m transformacion.generar_bronze --landing landing --lote-malo ruidoso
cd orquestacion
docker compose exec airflow airflow tasks clear tienda_diaria -s 2026-09-22 -e 2026-09-23 --only-failed -y
```

`transformar` falla con código 2 (lote rechazado) y `vigente.txt` se queda en el 21: falla cerrada.

Backfill de la primera semana:

```bash
docker compose exec airflow airflow backfill create --dag-id tienda_diaria \
  --from-date 2026-09-08T06:00:00-06:00 --to-date 2026-09-12T06:00:00-06:00 --reprocess-behavior completed
```

Las huellas de `lakehouse/metricas/*.json` no cambian y `vigente.txt` no se mueve.

### 5. Apaga

```bash
docker compose stop          # o: docker compose down -v para borrar la base de Airflow
```

### Sin Docker (Linux, macOS o WSL2)

```bash
python3 -m venv .venv-airflow && source .venv-airflow/bin/activate
pip install "apache-airflow==3.3.2" -r orquestacion/requirements-airflow.txt \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-3.3.2/constraints-$(python -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")').txt"
export AIRFLOW_HOME=$PWD/.airflow AIRFLOW__CORE__DAGS_FOLDER=$PWD/orquestacion/dags AIRFLOW__CORE__LOAD_EXAMPLES=False \
       AIRFLOW__CORE__SIMPLE_AUTH_MANAGER_ALL_ADMINS=True AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION=True PYTHONPATH=$PWD
airflow standalone
```

### Tarea de la sesión 3.1

1. Agrega a `tienda_diaria` una tarea `ventas_del_dia`, después de `transformar`, que lea
   `lakehouse/corte=<ds>/gold/ventas_diarias.parquet` e imprima el total del día anterior al corte.
2. Cambia `revisar_carga` para que sea UNA tarea mapeada (`revisar_carga.expand(tabla=TABLAS)`) en lugar de cuatro.
   ¿Qué cambia en la vista Grid?
3. Responde: si `transformar` escribiera siempre en `lakehouse/` (como en la 2.2), ¿qué quedaría publicado después del
   backfill de la primera semana? Pista: el backfill corrió varios días **al mismo tiempo**.
4. Proyecto final: convierte los pasos de tu `correr_todo.py` (tres extractores y la carga a bronze) en un DAG.
