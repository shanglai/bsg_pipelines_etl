import random
import socket

import pytest
import requests

from ingesta import api_caprichosa
from ingesta.cliente_http import ErrorNoReintentable, espera_backoff, get_con_reintentos


def puerto_libre():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_backoff_nunca_supera_el_tope():
    rng = random.Random(987654)
    esperas = [espera_backoff(i, base=0.5, tope=4, rng=rng) for i in range(1, 20)]
    assert all(0 <= e <= 4 for e in esperas)


def test_401_falla_de_inmediato_sin_reintentar():
    puerto = puerto_libre()
    srv, _ = api_caprichosa.iniciar(puerto, tasa_error=0.0)
    try:
        with pytest.raises(ErrorNoReintentable):
            get_con_reintentos(requests.Session(), f"http://127.0.0.1:{puerto}/v1/pedidos",
                               headers={"X-API-Key": "incorrecta"}, max_intentos=5)
    finally:
        srv.shutdown()


def test_se_recupera_de_errores_temporales():
    puerto = puerto_libre()
    srv, estado = api_caprichosa.iniciar(puerto, tasa_error=0.3, prob_lento=0.0)
    try:
        r = get_con_reintentos(requests.Session(), f"http://127.0.0.1:{puerto}/v1/pedidos",
                               headers={"X-API-Key": estado.api_key}, max_intentos=10, base=0.05, tope=0.2)
        assert r.status_code == 200 and len(r.json()["data"]) == 50
    finally:
        srv.shutdown()
