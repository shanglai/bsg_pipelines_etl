# Kit de ingesta · Sesión 1.2

**Curso:** Pipelines de Datos y ETL con Python · BSG Institute

Este kit es el mismo código del laboratorio de Colab, pero organizado como lo tendrías en un proyecto real:
módulos, configuración en `config.yaml`, secretos en `.env`, logs en archivo y códigos de salida para el orquestador.
Es la base del caso integrador: en las siguientes sesiones le iremos agregando piezas.

## Estructura

```
kit_ingesta_1_2/
├── config.yaml            # rutas, fuentes, contratos de proveedores, parámetros HTTP
├── .env.example           # plantilla de secretos (cópiala como .env)
├── requirements.txt
├── ingesta/
│   ├── logs.py            # logging estructurado en JSON
│   ├── cliente_http.py    # reintentos con backoff exponencial, jitter y Retry-After
│   ├── archivos.py        # contratos, landing zone, cuarentena y manifiesto
│   ├── apis.py            # catálogo (offset), tipo de cambio (rango) y pedidos (cursor + checkpoint)
│   ├── api_caprichosa.py  # servidor local que falla a propósito
│   ├── generar_datos.py   # archivos de proveedores con sus mañas
│   └── cli.py             # punto de entrada
└── tests/
    └── test_cliente_http.py
```

## Preparación (una sola vez)

Necesitas Python 3.11 o superior.

**Windows (PowerShell)**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Ejecución

Abre **dos terminales** con el entorno virtual activado.

**Terminal 1:** levanta la API caprichosa y déjala corriendo.
```bash
python -m ingesta.api_caprichosa
```

**Terminal 2:** genera los archivos de proveedores y corre la ingesta.
```bash
python -m ingesta.generar_datos
python -m ingesta.cli
```

Sin internet, agrega `--offline` y el catálogo y el tipo de cambio se leerán de los espejos locales:
```bash
python -m ingesta.cli --offline
```

Para correr una sola fuente: `python -m ingesta.cli --fuente pedidos`

Revisa el código de salida:
- Windows: `echo $LASTEXITCODE`
- macOS o Linux: `echo $?`

`0` significa que todo salió bien y `1` que alguna fuente falló.

## Qué revisar al terminar

| Carpeta | Qué contiene |
|---|---|
| `landing/raw/` | Las respuestas y archivos **tal como llegaron** |
| `landing/bronze/` | Parquet con metadatos (`_fuente`, `_cargado_en`, `_run_id`…) particionado por `fecha_carga=` |
| `landing/_cuarentena/` | Filas que no cumplieron el contrato |
| `landing/_manifiesto.jsonl` | Qué se ingestó, cuándo y con qué hash |
| `landing/_logs/` | Un evento JSON por línea |

## Tarea

1. Corre la ingesta dos veces. En la segunda, ¿qué dice el log de los archivos de proveedores? ¿Por qué?
2. Escribe en `config.yaml` el contrato del proveedor **oriente** y vuelve a correr `--fuente proveedores`.
3. Levanta la API con `--tasa-error 0.5`, corre `--fuente pedidos` y detén la ingesta con Ctrl+C a la mitad.
   Vuelve a correrla: ¿desde qué página continuó? Busca el evento `reanudando_desde_checkpoint`.
4. Corre las pruebas: `python -m pytest -q`

## Reglas del kit

- **Nunca** subas `.env` al repositorio (ya está en `.gitignore`).
- Nada se edita a mano dentro de `landing/raw`: lo que llegó, llegó.
- Si algo falla, el log debe decir **qué**, **dónde** y **con qué datos**.
