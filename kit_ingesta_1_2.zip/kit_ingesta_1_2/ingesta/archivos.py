"""Ingesta de archivos: detección, contratos por proveedor, landing zone, cuarentena y manifiesto."""
import csv
import hashlib
import json
import logging
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from charset_normalizer import from_path

from .logs import RUN_ID, evento

COLUMNAS_INVENTARIO = ["sku", "descripcion", "cantidad", "precio_unitario", "moneda", "fecha_corte"]


class ErrorCalidad(Exception):
    """Demasiadas filas rechazadas: el archivo no se publica en bronze."""


def sha256(ruta):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 16), b""):
            h.update(bloque)
    return h.hexdigest()


def escribir_atomico(destino, escribir):
    """Escribe en un temporal y lo renombra: nadie ve nunca un archivo a medias."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    temporal = destino.with_name(destino.name + ".tmp")
    escribir(temporal)
    os.replace(temporal, destino)


def detectar(ruta, muestra=20000):
    """Sugerencia automática de codificación y delimitador. Sirve para DESCUBRIR, no para OPERAR."""
    mejor = from_path(ruta).best()
    codificacion = mejor.encoding if mejor else "utf-8"
    with open(ruta, "rb") as f:
        texto = f.read(muestra).decode(codificacion, errors="replace")
    try:
        delimitador = csv.Sniffer().sniff(texto, delimiters=",;|\t").delimiter
    except csv.Error:
        delimitador = None
    return {"archivo": Path(ruta).name, "codificacion": codificacion, "delimitador": delimitador,
            "bom_utf8": texto.startswith("﻿"), "primera_linea": texto.lstrip("﻿").splitlines()[0][:80]}


def leer_con_contrato(ruta, contrato):
    """Lee un CSV aplicando el contrato del proveedor. Devuelve (DataFrame canónico, filas rechazadas)."""
    rechazadas = []

    def fila_mala(campos):
        rechazadas.append(contrato["sep"].join(campos))
        return None   # None = no incluir la fila, pero ya quedó registrada

    df = pd.read_csv(ruta, encoding=contrato["codificacion"], sep=contrato["sep"],
                     decimal=contrato.get("decimal", "."), thousands=contrato.get("miles"),
                     # el SKU siempre como texto: "00123" no es el número 123
                     dtype={origen: "string" for origen, canon in contrato["columnas"].items() if canon == "sku"},
                     engine="python", on_bad_lines=fila_mala)
    faltantes = set(contrato["columnas"]) - set(df.columns)
    if faltantes:
        raise ErrorCalidad(f"{Path(ruta).name}: faltan columnas del contrato {sorted(faltantes)}")
    df = df.rename(columns=contrato["columnas"])[COLUMNAS_INVENTARIO]
    df["sku"] = df["sku"].astype("string").str.strip()
    df["descripcion"] = df["descripcion"].astype("string").str.strip()
    df["moneda"] = df["moneda"].astype("string").str.strip().str.upper()
    df["cantidad"] = pd.to_numeric(df["cantidad"], errors="coerce").astype("Int64")
    df["precio_unitario"] = pd.to_numeric(df["precio_unitario"], errors="coerce")
    df["fecha_corte"] = pd.to_datetime(df["fecha_corte"], format=contrato["formato_fecha"], errors="coerce").dt.date
    # Filas que se leyeron pero traen valores inválidos también van a cuarentena
    invalidas = df["cantidad"].isna() | df["precio_unitario"].isna() | df["fecha_corte"].isna() | df["sku"].isna()
    for _, fila in df[invalidas].iterrows():
        rechazadas.append("valores inválidos: " + json.dumps(fila.astype(str).to_dict(), ensure_ascii=False))
    return df[~invalidas].reset_index(drop=True), rechazadas


class Manifiesto:
    """Registro de todo lo que se ha ingestado. Permite que la ingesta sea idempotente."""

    def __init__(self, landing):
        self.ruta = Path(landing) / "_manifiesto.jsonl"

    def entradas(self):
        if not self.ruta.exists():
            return []
        return [json.loads(l) for l in self.ruta.read_text(encoding="utf-8").splitlines() if l.strip()]

    def ya_ingestado(self, hash_archivo):
        return any(e.get("hash") == hash_archivo and e.get("estado") == "ok" for e in self.entradas())

    def registrar(self, **entrada):
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        with open(self.ruta, "a", encoding="utf-8") as f:
            f.write(json.dumps(entrada, ensure_ascii=False, default=str) + "\n")


def aterrizar_archivo(ruta, fuente, contrato, landing, fecha_carga, max_rechazo=0.05):
    """raw (copia exacta) -> lectura con contrato -> cuarentena -> bronze (Parquet) -> manifiesto."""
    ruta, landing = Path(ruta), Path(landing)
    manifiesto = Manifiesto(landing)
    h = sha256(ruta)
    if manifiesto.ya_ingestado(h):
        evento("archivo_omitido_ya_ingestado", fuente=fuente, archivo=ruta.name, hash=h[:12])
        return None

    particion = f"fecha_carga={fecha_carga}"
    destino_raw = landing / "raw" / "proveedores" / fuente / particion / ruta.name
    escribir_atomico(destino_raw, lambda tmp: shutil.copyfile(ruta, tmp))   # tal cual llegó

    df, rechazadas = leer_con_contrato(ruta, contrato)
    total = len(df) + len(rechazadas)
    tasa = len(rechazadas) / total if total else 0.0
    if rechazadas:
        destino_q = landing / "_cuarentena" / "proveedores" / fuente / particion / f"{h[:12]}.txt"
        escribir_atomico(destino_q, lambda tmp: Path(tmp).write_text("\n".join(rechazadas), encoding="utf-8"))
        evento("filas_en_cuarentena", logging.WARNING, fuente=fuente, archivo=ruta.name, filas=len(rechazadas), tasa=round(tasa, 3))
    if tasa > max_rechazo:
        manifiesto.registrar(hash=h, fuente=fuente, archivo=ruta.name, estado="rechazado", filas=len(df),
                             rechazadas=len(rechazadas), run_id=RUN_ID, ts=datetime.now(timezone.utc))
        raise ErrorCalidad(f"{ruta.name}: {tasa:.1%} de filas rechazadas supera el máximo de {max_rechazo:.0%}")

    df["_fuente"] = fuente
    df["_archivo"] = ruta.name
    df["_hash_archivo"] = h
    df["_cargado_en"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    df["_run_id"] = RUN_ID
    destino_bronze = landing / "bronze" / "inventario" / particion / f"fuente={fuente}" / f"{h[:12]}.parquet"
    escribir_atomico(destino_bronze, lambda tmp: df.to_parquet(tmp, index=False))

    manifiesto.registrar(hash=h, fuente=fuente, archivo=ruta.name, estado="ok", filas=len(df),
                         rechazadas=len(rechazadas), bytes=ruta.stat().st_size, destino=str(destino_bronze),
                         run_id=RUN_ID, ts=datetime.now(timezone.utc))
    evento("archivo_ingestado", fuente=fuente, archivo=ruta.name, filas=len(df), rechazadas=len(rechazadas))
    return df
