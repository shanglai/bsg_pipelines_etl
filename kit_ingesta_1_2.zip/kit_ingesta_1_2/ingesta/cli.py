"""Punto de entrada: python -m ingesta.cli --config config.yaml [--fuente todas] [--offline]

Códigos de salida (los usa el orquestador para saber si algo falló):
  0 = todo bien, 1 = al menos una fuente falló, 2 = error de configuración.
"""
import argparse
import logging
import os
import sys
from datetime import date
from pathlib import Path

import requests
import yaml
from dotenv import load_dotenv

from . import apis
from .archivos import aterrizar_archivo
from .cliente_http import sesion_con_retry
from .logs import RUN_ID, configurar_logs, evento

FUENTES = ("proveedores", "catalogo", "tipo_cambio", "pedidos")


def cargar_config(ruta):
    with open(ruta, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    fecha = cfg.get("fecha_carga", "hoy")
    cfg["fecha_carga"] = date.today().isoformat() if fecha in (None, "hoy") else str(fecha)
    return cfg


def correr_proveedores(cfg):
    fuente_cfg = cfg["fuentes"]["proveedores"]
    carpeta = Path(fuente_cfg["carpeta_entrada"])
    for nombre, contrato in fuente_cfg["contratos"].items():
        archivos = sorted(carpeta.glob(contrato["patron"]))
        if not archivos:
            evento("sin_archivos", logging.WARNING, fuente=nombre, patron=contrato["patron"])
        for archivo in archivos:
            aterrizar_archivo(archivo, nombre, contrato, cfg["landing"], cfg["fecha_carga"], cfg.get("max_rechazo", 0.05))


def main(argv=None):
    p = argparse.ArgumentParser(description="Ingesta del caso integrador (sesión 1.2)")
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--fuente", choices=("todas",) + FUENTES, default="todas")
    p.add_argument("--offline", action="store_true", help="usa los espejos locales de la API caprichosa")
    a = p.parse_args(argv)

    load_dotenv()   # lee .env si existe; nunca subas .env al repositorio
    try:
        cfg = cargar_config(a.config)
    except (OSError, yaml.YAMLError) as e:
        print(f"Error de configuración: {e}", file=sys.stderr)
        return 2
    configurar_logs(Path(cfg["landing"]) / "_logs" / f"ingesta_{cfg['fecha_carga']}.jsonl")
    evento("inicio", fuentes=a.fuente, fecha_carga=cfg["fecha_carga"], offline=a.offline)

    f, h = cfg["fuentes"], cfg["http"]
    urls = {"catalogo": f["catalogo"]["base_url"], "tipo_cambio": f["tipo_cambio"]["base_url"]}
    if a.offline:
        urls.update(cfg["offline"])
    sesion = sesion_con_retry()
    fallidas = []
    for nombre in (FUENTES if a.fuente == "todas" else (a.fuente,)):
        try:
            if nombre == "proveedores":
                correr_proveedores(cfg)
            elif nombre == "catalogo":
                apis.catalogo(sesion, urls["catalogo"], cfg["landing"], cfg["fecha_carga"], f["catalogo"]["tamano_pagina"])
            elif nombre == "tipo_cambio":
                t = f["tipo_cambio"]
                apis.tipo_cambio(sesion, urls["tipo_cambio"], cfg["landing"], cfg["fecha_carga"], t["base"], t["simbolos"], t["dias"])
            elif nombre == "pedidos":
                api_key = os.environ.get(f["pedidos"]["variable_api_key"])
                if not api_key:
                    raise RuntimeError(f"Falta la variable de entorno {f['pedidos']['variable_api_key']} (revisa tu .env)")
                apis.pedidos(requests.Session(), f["pedidos"]["base_url"], api_key, cfg["landing"], cfg["fecha_carga"],
                             f["pedidos"]["limite"], max_intentos=h["max_intentos"], base=h["backoff_base"],
                             tope=h["backoff_tope"], timeout=(h["timeout_conexion"], h["timeout_lectura"]))
        except Exception as e:
            fallidas.append(nombre)
            evento("fuente_fallida", logging.ERROR, fuente=nombre, error=f"{type(e).__name__}: {e}")
    evento("fin", fallidas=fallidas, run_id=RUN_ID)
    return 1 if fallidas else 0


if __name__ == "__main__":
    sys.exit(main())
