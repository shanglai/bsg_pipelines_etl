"""Genera los archivos de inventario de los proveedores, cada uno con sus propias mañas."""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

SEMILLA = 987654
PRODUCTOS = ["Camión de juguete", "Muñeca de trapo", "Almohada de algodón", "Cafetera eléctrica",
             "Pañuelo de seda", "Lámpara de escritorio", "Cuaderno profesional, 100 hojas", "Termo de acero",
             "Sartén antiadherente", "Mochila escolar", "Balón de fútbol", "Audífonos inalámbricos",
             "Juego de té de cerámica", "Cepillo de dientes eléctrico", "Añejo de agave 750 ml"]


def _filas(rng, n, corte):
    for i in range(n):
        yield {
            "sku": f"{rng.randint(1, 999):05d}",          # con ceros a la izquierda
            "descripcion": rng.choice(PRODUCTOS),
            "cantidad": rng.randint(0, 2500),
            "precio": round(rng.uniform(15, 4800), 2),
            "moneda": rng.choice(["MXN", "USD"]),
            "fecha": corte,
        }


def _miles_coma(x):
    """1234.5 -> '1.234,50' (formato de muchos países de habla hispana)."""
    return f"{x:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def generar(carpeta, corte=None, semilla=SEMILLA):
    carpeta = Path(carpeta)
    carpeta.mkdir(parents=True, exist_ok=True)
    rng = random.Random(semilla)
    corte = corte or (date.today() - timedelta(days=1))

    # Norte: el proveedor ordenado. UTF-8, coma, punto decimal, fecha ISO.
    with open(carpeta / "proveedor_norte.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["sku", "descripcion", "cantidad", "precio_unitario", "moneda", "fecha_corte"])
        for r in _filas(rng, 40, corte):
            w.writerow([r["sku"], r["descripcion"], r["cantidad"], f'{r["precio"]:.2f}', r["moneda"], r["fecha"].isoformat()])

    # Sur: Windows-1252, punto y coma, coma decimal y punto de miles, fecha dd/mm/aaaa, moneda en minúsculas.
    with open(carpeta / "proveedor_sur.csv", "w", encoding="cp1252", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Código", "Descripción", "Existencia", "Precio Unit.", "Moneda", "Fecha"])
        for r in _filas(rng, 40, corte):
            w.writerow([r["sku"], r["descripcion"], r["cantidad"], _miles_coma(r["precio"]), f' {r["moneda"].lower()} ',
                        r["fecha"].strftime("%d/%m/%Y")])

    # Centro: UTF-8 con BOM, pipe, fecha estilo EE. UU. (mm/dd/aaaa), una fila con un campo de más y un "N/D".
    with open(carpeta / "proveedor_centro.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter="|")
        w.writerow(["SKU", "DESCRIPCION", "QTY", "PRICE", "CURRENCY", "DATE"])
        for i, r in enumerate(_filas(rng, 45, corte)):
            cantidad = "N/D" if i == 17 else r["cantidad"]
            w.writerow([r["sku"], r["descripcion"], cantidad, f'{r["precio"]:.2f}', r["moneda"], r["fecha"].strftime("%m/%d/%Y")])
            if i == 30:
                f.write(f'99999|Producto misterioso|3|10.50|USD|{r["fecha"].strftime("%m/%d/%Y")}|CAMPO_EXTRA\r\n')

    # Oriente (reto): tabuladores, fecha dd-mm-aaaa y encabezados propios.
    with open(carpeta / "proveedor_oriente.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["item", "nombre", "unidades", "precio", "divisa", "corte"])
        for r in _filas(rng, 30, corte):
            w.writerow([r["sku"], r["descripcion"], r["cantidad"], f'{r["precio"]:.2f}', r["moneda"], r["fecha"].strftime("%d-%m-%Y")])

    return sorted(p.name for p in carpeta.glob("*.csv"))


if __name__ == "__main__":
    print(generar(Path("entrada/proveedores")))
