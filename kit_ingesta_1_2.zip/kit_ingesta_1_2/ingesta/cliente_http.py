"""Clientes HTTP robustos: timeouts, reintentos con backoff exponencial y jitter, y Retry-After."""
import logging
import random
import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .logs import evento

# 408 y 425: la solicitud puede repetirse; 429: límite de tasa; 5xx: problema del servidor
REINTENTABLES = {408, 425, 429, 500, 502, 503, 504}


class ErrorNoReintentable(Exception):
    """El servidor dijo que la solicitud está mal (400, 401, 403, 404...). Reintentar no ayuda."""


class ReintentosAgotados(Exception):
    """Se intentó varias veces y el problema temporal no se resolvió."""


def sesion_con_retry(max_intentos=5, backoff=0.5):
    """Opción declarativa: urllib3 reintenta por nosotros. Ideal para APIs bien portadas."""
    politica = Retry(total=max_intentos, backoff_factor=backoff, status_forcelist=sorted(REINTENTABLES),
                     allowed_methods=["GET"], respect_retry_after_header=True)
    sesion = requests.Session()
    sesion.mount("https://", HTTPAdapter(max_retries=politica))
    sesion.mount("http://", HTTPAdapter(max_retries=politica))
    sesion.headers["User-Agent"] = "bsg-curso-pipelines/1.2"
    return sesion


def espera_backoff(intento, base=0.5, tope=20.0, rng=random):
    """Backoff exponencial con 'full jitter': un valor al azar entre 0 y min(tope, base * 2^intento)."""
    return rng.uniform(0, min(tope, base * 2 ** intento))


def _retry_after(respuesta):
    valor = respuesta.headers.get("Retry-After", "")
    try:
        return max(0.0, float(valor))
    except ValueError:
        return None   # también puede venir como fecha HTTP; en ese caso usamos backoff


def get_con_reintentos(sesion, url, *, params=None, headers=None, max_intentos=6,
                       timeout=(3.05, 10), base=0.5, tope=20.0, rng=random):
    """GET que distingue errores temporales (reintenta) de errores definitivos (falla de inmediato)."""
    motivo = "sin intentos"
    for intento in range(1, max_intentos + 1):
        inicio = time.perf_counter()
        try:
            r = sesion.get(url, params=params, headers=headers, timeout=timeout)
        except (requests.Timeout, requests.ConnectionError) as e:
            motivo = type(e).__name__
            espera = espera_backoff(intento, base, tope, rng)
        else:
            ms = round((time.perf_counter() - inicio) * 1000)
            if r.status_code < 400:
                evento("http_ok", url=url, params=params, status=r.status_code, intento=intento, ms=ms)
                return r
            if r.status_code not in REINTENTABLES:
                evento("http_error_definitivo", logging.ERROR, url=url, status=r.status_code, cuerpo=r.text[:200])
                raise ErrorNoReintentable(f"HTTP {r.status_code} en {url}: {r.text[:200]}")
            motivo = f"HTTP {r.status_code}"
            ra = _retry_after(r)
            espera = ra if ra is not None else espera_backoff(intento, base, tope, rng)
        if intento == max_intentos:
            break
        evento("http_reintento", logging.WARNING, url=url, motivo=motivo, intento=intento, espera_s=round(espera, 2))
        time.sleep(espera)
    evento("http_reintentos_agotados", logging.ERROR, url=url, intentos=max_intentos, ultimo_motivo=motivo)
    raise ReintentosAgotados(f"{url}: {max_intentos} intentos sin éxito (último motivo: {motivo})")
