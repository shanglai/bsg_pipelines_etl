"""Kit de ingesta del caso integrador: curso Pipelines de Datos y ETL con Python (BSG Institute)."""
