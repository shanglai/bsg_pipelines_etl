"""Logging estructurado: cada evento es una línea JSON que se puede consultar como datos."""
import json
import logging
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

RUN_ID = uuid.uuid4().hex[:12]   # identifica una ejecución completa del pipeline


class FormatoJSON(logging.Formatter):
    def format(self, registro):
        linea = {
            "ts": datetime.fromtimestamp(registro.created, tz=timezone.utc).isoformat(timespec="milliseconds"),
            "nivel": registro.levelname,
            "evento": registro.getMessage(),
            "run_id": RUN_ID,
        }
        linea.update(getattr(registro, "campos", {}))
        if registro.exc_info:
            linea["error"] = self.formatException(registro.exc_info).splitlines()[-1]
        return json.dumps(linea, ensure_ascii=False, default=str)


def configurar_logs(archivo=None, nivel="INFO"):
    """Envía los eventos a la consola y, opcionalmente, a un archivo .jsonl."""
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    log = logging.getLogger("ingesta")
    log.setLevel(nivel)
    log.handlers.clear()
    log.propagate = False
    consola = logging.StreamHandler(sys.stdout)
    consola.setFormatter(FormatoJSON())
    log.addHandler(consola)
    if archivo:
        Path(archivo).parent.mkdir(parents=True, exist_ok=True)
        disco = logging.FileHandler(archivo, encoding="utf-8")
        disco.setFormatter(FormatoJSON())
        log.addHandler(disco)
    return log


def evento(nombre, nivel=logging.INFO, **campos):
    """Registra un evento con campos estructurados: evento("archivo_ingestado", filas=120)."""
    logging.getLogger("ingesta").log(nivel, nombre, extra={"campos": campos})
