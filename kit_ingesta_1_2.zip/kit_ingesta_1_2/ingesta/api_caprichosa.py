"""API caprichosa: un servidor local que se porta como las APIs reales en un mal día.

- /v1/pedidos      requiere X-API-Key, paginación por cursor, límite de tasa (429 + Retry-After),
                   errores 500/503 aleatorios y respuestas lentas.
- /dummyjson/...   espejo sin caos de dummyjson.com (para trabajar sin internet).
- /frankfurter/... espejo sin caos de api.frankfurter.dev/v1 (para trabajar sin internet).

Uso local:  python -m ingesta.api_caprichosa --puerto 8765 --tasa-error 0.15
"""
import argparse
import base64
import json
import random
import threading
import time
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

SEMILLA = 987654


class Estado:
    def __init__(self, api_key="bsg-demo-2026", tasa_error=0.15, prob_lento=0.05, segundos_lento=4.0,
                 peticiones_por_segundo=4, n_pedidos=500, semilla=SEMILLA):
        self.api_key, self.tasa_error, self.prob_lento = api_key, tasa_error, prob_lento
        self.segundos_lento, self.capacidad = segundos_lento, peticiones_por_segundo
        self.tokens, self.ultimo = float(peticiones_por_segundo), time.monotonic()
        self.rng, self.lock = random.Random(semilla), threading.Lock()
        datos = random.Random(semilla + 1)
        inicio = date.today() - timedelta(days=30)
        self.pedidos = [{
            "id": 100000 + i, "cliente_id": datos.randint(1, 800),
            "fecha": (inicio + timedelta(days=datos.randint(0, 29))).isoformat(),
            "total": round(datos.uniform(99, 25000), 2), "moneda": datos.choice(["MXN", "MXN", "MXN", "USD"]),
            "estado": datos.choice(["pagado", "enviado", "entregado", "cancelado"]), "articulos": datos.randint(1, 9),
        } for i in range(n_pedidos)]
        categorias = ["beauty", "fragrances", "furniture", "groceries", "home-decoration", "kitchen-accessories", "laptops"]
        self.productos = [{"id": i, "title": f"Producto sintético {i}", "category": datos.choice(categorias),
                           "price": round(datos.uniform(1, 2500), 2), "stock": datos.randint(0, 150),
                           "brand": datos.choice(["Acme", "Globex", None]), "sku": f"SIN-{i:05d}"} for i in range(1, 195)]

    def consumir_token(self):
        """Token bucket: se recargan `capacidad` tokens por segundo; sin token -> 429."""
        with self.lock:
            ahora = time.monotonic()
            self.tokens = min(self.capacidad, self.tokens + (ahora - self.ultimo) * self.capacidad)
            self.ultimo = ahora
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def tirar_dado(self):
        with self.lock:
            return self.rng.random(), self.rng.random(), self.rng.choice([500, 503])


def _cursor(offset):
    return base64.urlsafe_b64encode(json.dumps({"o": offset}).encode()).decode()


def _offset(cursor):
    return json.loads(base64.urlsafe_b64decode(cursor.encode()))["o"]


def crear_manejador(estado):
    class Manejador(BaseHTTPRequestHandler):
        def log_message(self, *args):   # silencio: el cliente es quien debe registrar
            pass

        def _json(self, codigo, cuerpo, encabezados=None):
            datos = json.dumps(cuerpo, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(datos)))
            for k, v in (encabezados or {}).items():
                self.send_header(k, str(v))
            self.end_headers()
            try:
                self.wfile.write(datos)
            except (BrokenPipeError, ConnectionResetError):
                pass   # el cliente se rindió (timeout) antes de que respondiéramos

        def do_GET(self):
            url = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            ruta = url.path.rstrip("/")
            if ruta == "/salud":
                return self._json(200, {"ok": True})
            if ruta == "/dummyjson/products":
                limite, salto = int(q.get("limit", 30)), int(q.get("skip", 0))
                return self._json(200, {"products": estado.productos[salto:salto + limite],
                                        "total": len(estado.productos), "skip": salto, "limit": limite})
            if ruta.startswith("/frankfurter/"):
                desde, hasta = ruta.split("/")[-1].split("..")
                simbolos = q.get("symbols", "MXN,BRL,EUR").split(",")
                d, h, tasas = date.fromisoformat(desde), date.fromisoformat(hasta), {}
                base = {"MXN": 17.0, "BRL": 5.1, "EUR": 0.86}
                rng = random.Random(SEMILLA)
                while d <= h:
                    if d.weekday() < 5:
                        tasas[d.isoformat()] = {s: round(base.get(s, 1.0) * rng.uniform(0.98, 1.02), 4) for s in simbolos}
                    d += timedelta(days=1)
                return self._json(200, {"amount": 1.0, "base": q.get("base", "USD"), "start_date": desde,
                                        "end_date": hasta, "rates": tasas})
            if ruta == "/v1/pedidos":
                if self.headers.get("X-API-Key") != estado.api_key:
                    return self._json(401, {"error": "API key inválida o ausente"})
                if not estado.consumir_token():
                    return self._json(429, {"error": "demasiadas solicitudes"}, {"Retry-After": 1})
                dado_error, dado_lento, codigo = estado.tirar_dado()
                if dado_error < estado.tasa_error:
                    return self._json(codigo, {"error": "falla temporal del servidor"})
                if dado_lento < estado.prob_lento:
                    time.sleep(estado.segundos_lento)
                limite = min(int(q.get("limit", 50)), 100)
                try:
                    salto = _offset(q["cursor"]) if q.get("cursor") else 0
                except Exception:
                    return self._json(400, {"error": "cursor inválido"})
                pagina = estado.pedidos[salto:salto + limite]
                siguiente = _cursor(salto + limite) if salto + limite < len(estado.pedidos) else None
                return self._json(200, {"data": pagina, "next_cursor": siguiente},
                                  {"X-Total-Count": len(estado.pedidos)})
            return self._json(404, {"error": f"ruta desconocida: {ruta}"})

    return Manejador


def iniciar(puerto=8765, **config):
    """Levanta el servidor en un hilo de fondo. Devuelve (servidor, estado)."""
    estado = Estado(**config)
    servidor = ThreadingHTTPServer(("127.0.0.1", puerto), crear_manejador(estado))
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    return servidor, estado


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="API caprichosa para practicar ingesta robusta")
    p.add_argument("--puerto", type=int, default=8765)
    p.add_argument("--tasa-error", type=float, default=0.15)
    p.add_argument("--prob-lento", type=float, default=0.05)
    p.add_argument("--api-key", default="bsg-demo-2026")
    a = p.parse_args()
    estado = Estado(api_key=a.api_key, tasa_error=a.tasa_error, prob_lento=a.prob_lento)
    srv = ThreadingHTTPServer(("127.0.0.1", a.puerto), crear_manejador(estado))
    print(f"API caprichosa escuchando en http://127.0.0.1:{a.puerto}  (Ctrl+C para detener)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nDetenida.")
