"""Ingesta desde APIs: paginación por offset (catálogo), rango de fechas (tipo de cambio) y cursor (pedidos)."""
import json
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from .archivos import escribir_atomico
from .cliente_http import get_con_reintentos
from .logs import RUN_ID, evento


def _guardar_json(destino, cuerpo):
    escribir_atomico(destino, lambda tmp: Path(tmp).write_text(json.dumps(cuerpo, ensure_ascii=False), encoding="utf-8"))


def _metadatos(df, fuente):
    df["_fuente"] = fuente
    df["_cargado_en"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    df["_run_id"] = RUN_ID
    return df


def catalogo(sesion, base_url, landing, fecha_carga, tamano_pagina=30):
    """Paginación por offset (limit/skip). La sesión ya trae reintentos declarativos (urllib3)."""
    particion = Path(landing) / "raw" / "catalogo" / f"fecha_carga={fecha_carga}"
    productos, salto, pagina, total = [], 0, 0, None
    while True:
        r = sesion.get(f"{base_url}/products", timeout=(3.05, 15),
                       params={"limit": tamano_pagina, "skip": salto, "select": "title,category,price,stock,brand,sku"})
        r.raise_for_status()
        cuerpo = r.json()
        _guardar_json(particion / f"pagina_{pagina:04d}.json", cuerpo)   # raw: la respuesta tal cual
        total = cuerpo["total"]
        productos.extend(cuerpo["products"])
        evento("pagina_descargada", fuente="catalogo", pagina=pagina, registros=len(cuerpo["products"]), acumulado=len(productos), total=total)
        salto += len(cuerpo["products"])
        pagina += 1
        if not cuerpo["products"] or salto >= total:
            break
    df = pd.DataFrame(productos)
    for col in ("title", "category", "price", "stock", "brand", "sku"):
        if col not in df:
            df[col] = None   # algunos productos no traen todos los campos
    if len(df) != total or not df["id"].is_unique:
        raise ValueError(f"Catálogo incompleto o duplicado: {len(df)} filas, {df['id'].nunique()} únicas, total esperado {total}")
    destino = Path(landing) / "bronze" / "catalogo" / f"fecha_carga={fecha_carga}" / "catalogo.parquet"
    escribir_atomico(destino, lambda tmp: _metadatos(df, "dummyjson").to_parquet(tmp, index=False))
    evento("fuente_completa", fuente="catalogo", filas=len(df), paginas=pagina)
    return df


def tipo_cambio(sesion, base_url, landing, fecha_carga, base="USD", simbolos=("MXN", "BRL", "EUR"), dias=30):
    """Una sola llamada por rango de fechas; aplanamos {fecha: {moneda: tasa}} a filas."""
    hasta = date.fromisoformat(str(fecha_carga))
    desde = hasta - timedelta(days=dias)
    r = sesion.get(f"{base_url}/{desde}..{hasta}", params={"base": base, "symbols": ",".join(simbolos)}, timeout=(3.05, 15))
    r.raise_for_status()
    cuerpo = r.json()
    _guardar_json(Path(landing) / "raw" / "tipo_cambio" / f"fecha_carga={fecha_carga}" / "respuesta.json", cuerpo)
    filas = [{"fecha": f, "moneda_base": cuerpo["base"], "moneda": m, "tasa": t}
             for f, tasas in cuerpo["rates"].items() for m, t in tasas.items()]
    df = pd.DataFrame(filas)
    destino = Path(landing) / "bronze" / "tipo_cambio" / f"fecha_carga={fecha_carga}" / "tipo_cambio.parquet"
    escribir_atomico(destino, lambda tmp: _metadatos(df, "frankfurter").to_parquet(tmp, index=False))
    evento("fuente_completa", fuente="tipo_cambio", filas=len(df), desde=str(desde), hasta=str(hasta))
    return df


def pedidos(sesion, base_url, api_key, landing, fecha_carga, limite=50, reanudar=True, **opciones_http):
    """Paginación por cursor, con checkpoint: si falla a la mitad, la siguiente corrida continúa donde se quedó."""
    landing = Path(landing)
    raw = landing / "raw" / "pedidos" / f"fecha_carga={fecha_carga}"
    checkpoint = landing / "_checkpoints" / f"pedidos_{fecha_carga}.json"
    cursor, pagina = None, 0
    if reanudar and checkpoint.exists():
        estado = json.loads(checkpoint.read_text(encoding="utf-8"))
        cursor, pagina = estado["cursor"], estado["pagina"]
        evento("reanudando_desde_checkpoint", fuente="pedidos", pagina=pagina)
    total_esperado = None
    while True:
        params = {"limit": limite, **({"cursor": cursor} if cursor else {})}
        r = get_con_reintentos(sesion, f"{base_url}/v1/pedidos", params=params,
                               headers={"X-API-Key": api_key}, **opciones_http)
        cuerpo = r.json()
        total_esperado = int(r.headers.get("X-Total-Count", 0)) or total_esperado
        escribir_atomico(raw / f"pagina_{pagina:04d}.jsonl",
                         lambda tmp: Path(tmp).write_text("".join(json.dumps(p, ensure_ascii=False) + "\n" for p in cuerpo["data"]), encoding="utf-8"))
        cursor, pagina = cuerpo["next_cursor"], pagina + 1
        if cursor is None:
            break
        escribir_atomico(checkpoint, lambda tmp: Path(tmp).write_text(json.dumps({"cursor": cursor, "pagina": pagina}), encoding="utf-8"))
    # Consolidamos todas las páginas crudas (incluidas las de corridas anteriores) y validamos contra el total
    df = pd.concat([pd.read_json(p, lines=True) for p in sorted(raw.glob("pagina_*.jsonl"))], ignore_index=True)
    df = df.drop_duplicates(subset="id")
    if total_esperado and len(df) != total_esperado:
        raise ValueError(f"Pedidos incompletos: {len(df)} de {total_esperado}")
    destino = landing / "bronze" / "pedidos" / f"fecha_carga={fecha_carga}" / "pedidos.parquet"
    escribir_atomico(destino, lambda tmp: _metadatos(df, "api_caprichosa").to_parquet(tmp, index=False))
    checkpoint.unlink(missing_ok=True)
    evento("fuente_completa", fuente="pedidos", filas=len(df), paginas=pagina)
    return df
