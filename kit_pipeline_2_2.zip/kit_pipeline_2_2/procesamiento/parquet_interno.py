"""Mirar dentro de un Parquet: row groups, estadísticas min/max y cuánto se puede saltar al filtrar."""
import time
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd
import pyarrow.parquet as pq


def row_groups(ruta, columna="fecha"):
    """Una fila por row group con su número de filas y el min/max de la columna (guardados en el pie del archivo)."""
    meta = pq.ParquetFile(ruta).metadata
    idx = meta.schema.to_arrow_schema().get_field_index(columna)
    filas = []
    for i in range(meta.num_row_groups):
        rg = meta.row_group(i)
        est = rg.column(idx).statistics
        filas.append({"row_group": i, "filas": rg.num_rows, "min": est.min, "max": est.max,
                      "mb_comprimido": round(rg.total_byte_size / 2**20, 1)})
    return pd.DataFrame(filas)


def row_groups_necesarios(ruta, desde, hasta, columna="fecha"):
    """¿Cuántos row groups PODRÍAN contener filas en [desde, hasta)? El resto se salta sin leerlos."""
    rg = row_groups(ruta, columna)
    tocan = rg[(rg["max"] >= desde) & (rg["min"] < hasta)]
    return len(tocan), len(rg)


def tiempo_filtro(fuente, desde, hasta, repeticiones=3):
    """Tiempo de una consulta filtrada por fecha con DuckDB (mejor de varias corridas)."""
    sql = f"""SELECT COUNT(*) AS lineas, ROUND(SUM(cantidad * precio_unitario), 2) AS venta
              FROM {fuente} WHERE fecha >= TIMESTAMP '{desde:%Y-%m-%d}' AND fecha < TIMESTAMP '{hasta:%Y-%m-%d}'"""
    mejor, resultado = None, None
    for _ in range(repeticiones):
        inicio = time.perf_counter()
        resultado = duckdb.execute(sql).fetchone()
        t = time.perf_counter() - inicio
        mejor = t if mejor is None else min(mejor, t)
    return round(mejor, 3), resultado


def comparar_saltos(carpeta, desde=datetime(2025, 12, 1), hasta=datetime(2026, 1, 1)):
    d = Path(carpeta).as_posix()
    fuentes = {
        "Parquet sin ordenar": f"read_parquet('{d}/lineas.parquet')",
        "Parquet ordenado por fecha": f"read_parquet('{d}/lineas_ordenado.parquet')",
        "Particionado por año/mes": f"read_parquet('{d}/lineas_particionado/**/*.parquet', hive_partitioning = true)",
    }
    filas = []
    for nombre, fuente in fuentes.items():
        t, (lineas, venta) = tiempo_filtro(fuente, desde, hasta)
        fila = {"fuente": nombre, "segundos": t, "lineas": lineas, "venta": venta}
        if "particionado" not in nombre.lower():
            archivo = f"{d}/{'lineas_ordenado' if 'ordenado' in nombre else 'lineas'}.parquet"
            necesarios, total = row_groups_necesarios(archivo, desde, hasta)
            fila["row_groups_a_leer"] = f"{necesarios} de {total}"
        else:
            fila["row_groups_a_leer"] = "solo la carpeta mes=12"
        filas.append(fila)
    return pd.DataFrame(filas).set_index("fuente")
