"""Tablero de ventas sobre la capa gold (sesión 2.3).

  streamlit run tablero/app.py

Lee SOLO gold (gold.mart_ventas_diarias) en modo de solo lectura: el tablero no limpia ni corrige nada.
"""
import os
from datetime import timedelta

import duckdb
import polars as pl
import streamlit as st

BD = os.environ.get("DBT_DUCKDB_PATH", "elt/tienda.duckdb")

st.set_page_config(page_title="Ventas de la tienda", layout="wide")


@st.cache_data(ttl=60)
def cargar():
    with duckdb.connect(BD, read_only=True) as c:
        return c.sql("SELECT * FROM gold.mart_ventas_diarias").pl()


ventas = cargar()
ultimo = ventas["fecha_negocio"].max()
st.title("Ventas de la tienda")
st.caption(f"Fuente: gold.mart_ventas_diarias · datos hasta el {ultimo:%d/%m/%Y}")
st.warning(f"El {ultimo:%d/%m/%Y} está incompleto: la última carga es de la madrugada. No lo leas como una caída.")

col1, col2, col3 = st.columns(3)
desde = col1.date_input("Desde", ultimo - timedelta(days=13))
ciudades = col2.multiselect("Ciudad", sorted(ventas["ciudad"].unique().to_list()))
canales = col3.multiselect("Canal", sorted(ventas["canal"].unique().to_list()))

v = ventas.filter(pl.col("fecha_negocio") >= desde)
if ciudades:
    v = v.filter(pl.col("ciudad").is_in(ciudades))
if canales:
    v = v.filter(pl.col("canal").is_in(canales))

k1, k2, k3 = st.columns(3)
k1.metric("Ingreso (MXN)", f"{v['ingreso_mxn'].sum():,.0f}")
k2.metric("Pedidos", f"{v['pedidos'].sum():,}")
k3.metric("Ticket promedio (MXN)", f"{v['ingreso_mxn'].sum() / max(v['pedidos'].sum(), 1):,.0f}")

por_dia = v.group_by("fecha_negocio").agg(pl.col("ingreso_mxn").sum()).sort("fecha_negocio")
st.subheader("Ingreso por día")
st.line_chart(por_dia.to_pandas(), x="fecha_negocio", y="ingreso_mxn")

st.subheader("Ingreso por ciudad (ciudad del cliente el día de la venta)")
por_ciudad = v.group_by("ciudad").agg(pl.col("ingreso_mxn").sum()).sort("ingreso_mxn", descending=True)
st.bar_chart(por_ciudad.to_pandas(), x="ciudad", y="ingreso_mxn", horizontal=True)
