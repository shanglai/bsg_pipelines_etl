"""ETL (sesiones 2.1 y 2.2, en Python) contra ELT (sesión 2.3, dbt dentro de DuckDB): deben dar lo mismo.

Correr:  pytest -q tests/test_elt.py     (tarda alrededor de un minuto: corre dbt de punta a punta)
"""
import importlib.util
import json
from pathlib import Path

import duckdb
import polars as pl
import pytest

from transformacion import generar_bronze, pipeline

ELT = Path(__file__).resolve().parent.parent / "elt"
spec = importlib.util.spec_from_file_location("correr_elt", ELT / "correr.py")
correr_elt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(correr_elt)


@pytest.fixture(scope="module")
def mundo(tmp_path_factory):
    base = tmp_path_factory.mktemp("mundo")
    generar_bronze.generar(base / "landing")
    etl = pipeline.correr(base / "landing", base / "lakehouse")
    import os
    os.environ["DBT_DUCKDB_PATH"] = str(base / "tienda.duckdb")
    assert correr_elt.main(["--landing", str(base / "landing")]) == 0
    return base, etl


def test_mismos_pedidos_y_cuarentena(mundo):
    base, etl = mundo
    with duckdb.connect(str(base / "tienda.duckdb"), read_only=True) as c:
        assert c.execute("SELECT count(*) FROM gold.fct_pedidos").fetchone()[0] == etl["silver_pedidos"]
        assert c.execute("SELECT count(*) FROM silver.int_pedidos_cuarentena").fetchone()[0] == etl["cuarentena"]
        assert c.execute("SELECT count(*) FROM gold.dim_cliente_historia").fetchone()[0] == etl["clientes_versiones"]


def test_mismo_ingreso_por_ciudad(mundo):
    base, _ = mundo
    py = (pl.read_parquet(base / "lakehouse" / "gold" / "ventas_diarias.parquet")
          .group_by("ciudad").agg(pl.col("ingreso_mxn").sum().round(0)).sort("ciudad"))
    with duckdb.connect(str(base / "tienda.duckdb"), read_only=True) as c:
        sql = c.sql("SELECT ciudad, round(sum(ingreso_mxn), 0) AS ingreso_mxn FROM gold.mart_ventas_diarias "
                    "GROUP BY 1 ORDER BY 1").pl()
    assert py["ciudad"].to_list() == sql["ciudad"].to_list()
    assert (py["ingreso_mxn"] - sql["ingreso_mxn"]).abs().max() <= 1


def test_lote_malo_detiene_gold(mundo):
    base, _ = mundo
    with duckdb.connect(str(base / "tienda.duckdb"), read_only=True) as c:
        antes = c.execute("SELECT round(sum(ingreso_mxn), 2) FROM gold.mart_ventas_diarias").fetchone()[0]
    generar_bronze.generar(base / "landing", lote_malo="ruidoso")
    assert correr_elt.main(["--landing", str(base / "landing"), "--solo-build"]) == 2
    resultados = json.loads((ELT / "target" / "run_results.json").read_text(encoding="utf-8"))["results"]
    fallas = [r["unique_id"] for r in resultados if r["status"] == "fail"]
    assert any("assert_rechazo_por_carga" in f for f in fallas)
    with duckdb.connect(str(base / "tienda.duckdb"), read_only=True) as c:
        assert c.execute("SELECT round(sum(ingreso_mxn), 2) FROM gold.mart_ventas_diarias").fetchone()[0] == antes
