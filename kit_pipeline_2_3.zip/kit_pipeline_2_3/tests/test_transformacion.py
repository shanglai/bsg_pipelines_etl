"""Pruebas de las transformaciones (sesiones 2.1 y 2.2).

Cada prueba arma un DataFrame chico A MANO con el caso que nos importa. Si una prueba necesita leer un archivo
para probar una regla de negocio, la función está mal diseñada (mezcla E/S con lógica).
Correr:  pytest -q tests/test_transformacion.py
"""
from datetime import date, datetime, timezone

import polars as pl
import pytest

from transformacion import calidad, dedup, enriquecer, gold, limpieza, scd

UTC = timezone.utc


def utc(*args):
    return datetime(*args, tzinfo=UTC)


# ---------------------------------------------------------------- limpieza
def test_estado_reconoce_variantes_y_no_inventa():
    df = pl.DataFrame({"estado": ["PAGADO ", " enviado", "Entregado", "pagdo", None]})
    assert df.select(limpieza.estado())["estado"].to_list() == ["pagado", "enviado", "entregado", None, None]


def test_moneda_moneda_nacional_es_mxn():
    df = pl.DataFrame({"moneda": ["MN", "mxn", " USD", "US$", "EUR"]})
    assert df.select(limpieza.moneda())["moneda"].to_list() == ["MXN", "MXN", "USD", "USD", None]


def test_ciudad_misma_ciudad_cinco_formas():
    df = pl.DataFrame({"ciudad": ["Ciudad de México", "cdmx", "CDMX ", "Cd. de México", "CIUDAD DE MEXICO", "QUERETARO", "Atlantis"]})
    assert df.select(limpieza.ciudad())["ciudad"].to_list() == ["CDMX"] * 5 + ["Querétaro", None]


def test_importe_con_formato_de_moneda():
    df = pl.DataFrame({"i": ["$1,234.50", "$99.00", "N/D"]})
    assert df.select(limpieza.importe("i"))["i"].to_list() == [1234.5, 99.0, None]


def test_tienda_hora_local_a_utc_y_cliente_desconocido():
    df = pl.DataFrame({"folio": ["7"], "sucursal": ["CDMX-Centro"], "cliente": [""], "fecha_hora": ["15/09/2026 21:30:00"],
                       "importe": ["$500.00"], "moneda": ["MN"], "estatus": ["VENTA"], "fecha_carga": [date(2026, 9, 16)]})
    r = limpieza.conformar_tienda(df).row(0, named=True)
    assert r["creado_en"] == utc(2026, 9, 16, 3, 30)          # 21:30 en CDMX = 03:30 del día siguiente en UTC
    assert r["cliente_id"] == limpieza.CLIENTE_DESCONOCIDO
    assert (r["origen"], r["estado"], r["moneda"], r["total"]) == ("tienda", "entregado", "MXN", 500.0)


def test_fecha_de_negocio_es_la_de_mexico():
    df = pl.DataFrame({"creado_en": [utc(2026, 9, 16, 3, 30), utc(2026, 9, 16, 12, 0)]})
    assert df.select(limpieza.fecha_negocio())["creado_en"].to_list() == [date(2026, 9, 15), date(2026, 9, 16)]


# ---------------------------------------------------------------- deduplicación
def _versiones():
    return pl.DataFrame({
        "origen": ["web", "web", "web", "tienda", "web", "web"],
        "pedido_id": [1, 1, 1, 1, 2, 2],
        "estado": ["pagado", "enviado", "enviado", "entregado", "entregado", "cancelado"],
        "actualizado_en": [utc(2026, 9, 1), utc(2026, 9, 2), utc(2026, 9, 2), utc(2026, 9, 1), utc(2026, 9, 5), utc(2026, 9, 5)],
        "_extraido_en": [utc(2026, 9, 2), utc(2026, 9, 3), utc(2026, 9, 3), utc(2026, 9, 2), utc(2026, 9, 6), utc(2026, 9, 9)],
    })


def test_ultima_version_por_llave_de_negocio():
    u = dedup.ultima_version(_versiones()).sort("origen", "pedido_id")
    assert u.select("origen", "pedido_id", "estado").rows() == [("tienda", 1, "entregado"), ("web", 1, "enviado"), ("web", 2, "cancelado")]


def test_unique_ingenuo_no_basta():
    assert len(_versiones().unique()) == 5      # quita el duplicado exacto, pero deja 2 versiones del pedido web 1


def test_empate_lo_resuelve_la_extraccion_mas_reciente():
    u = dedup.ultima_version(_versiones())
    assert u.filter((pl.col("origen") == "web") & (pl.col("pedido_id") == 2))["estado"].item() == "cancelado"


# ---------------------------------------------------------------- tipo de cambio
@pytest.fixture
def tc():
    return pl.DataFrame({"fecha": [date(2026, 9, 11), date(2026, 9, 14)], "mxn_por_usd": [18.0, 18.5]})


def _pedidos_usd(*momentos):
    return pl.DataFrame({"pedido_id": list(range(len(momentos))), "creado_en": list(momentos),
                         "total": [10.0] * len(momentos), "moneda": ["USD"] * len(momentos)})


def test_sabado_usa_la_tasa_del_viernes(tc):
    p = _pedidos_usd(utc(2026, 9, 12, 18), utc(2026, 9, 14, 18))      # sábado y lunes
    r = enriquecer.con_tipo_cambio(p, tc).sort("pedido_id")
    assert r["total_mxn"].to_list() == [180.0, 185.0]
    assert r["fecha_tc"].to_list() == [date(2026, 9, 11), date(2026, 9, 14)]


def test_join_ingenuo_pierde_el_fin_de_semana(tc):
    p = _pedidos_usd(utc(2026, 9, 12, 18), utc(2026, 9, 14, 18))
    assert len(enriquecer.con_tipo_cambio_ingenuo(p, tc)) == 1


def test_tasa_corregida_gana_la_carga_mas_reciente():
    b = pl.DataFrame({"fecha": [date(2026, 9, 11)] * 2, "base": ["USD"] * 2, "moneda": ["MXN"] * 2,
                      "tasa": [18.30, 18.35], "fecha_carga": [date(2026, 9, 12), date(2026, 9, 14)]})
    assert enriquecer.tipo_cambio_diario(b)["mxn_por_usd"].to_list() == [18.35]


# ---------------------------------------------------------------- SCD
def _foto(ciudad="CDMX", segmento="nuevo", email="a@x.mx", ids=(1,)):
    return pl.DataFrame({"cliente_id": list(ids), "ciudad": [ciudad] * len(ids), "segmento": [segmento] * len(ids),
                         "email": [email] * len(ids)})


def test_scd2_cambio_cierra_y_abre_version():
    h = scd.scd2(None, _foto("CDMX"), date(2026, 9, 8))
    h = scd.scd2(h, _foto("Tijuana"), date(2026, 9, 12))
    assert h.select("ciudad", "valido_desde", "valido_hasta", "vigente", "version").rows() == [
        ("CDMX", scd.INICIO, date(2026, 9, 12), False, 1),
        ("Tijuana", date(2026, 9, 12), scd.FIN, True, 2)]


def test_scd2_aplicar_dos_veces_la_misma_foto_no_cambia_nada():
    h = scd.scd2(scd.scd2(None, _foto("CDMX"), date(2026, 9, 8)), _foto("Tijuana"), date(2026, 9, 12))
    assert scd.scd2(h, _foto("Tijuana"), date(2026, 9, 12)).equals(h)


def test_scd2_cambio_que_se_revierte_son_tres_versiones():
    h = scd.scd2(None, _foto("CDMX"), date(2026, 9, 8))
    h = scd.scd2(h, _foto("Tijuana"), date(2026, 9, 12))
    h = scd.scd2(h, _foto("CDMX"), date(2026, 9, 15))
    assert h["ciudad"].to_list() == ["CDMX", "Tijuana", "CDMX"]


def test_scd2_baja_cierra_sin_abrir():
    h = scd.scd2(None, _foto(ids=(1, 2)), date(2026, 9, 8))
    h = scd.scd2(h, _foto(ids=(1,)), date(2026, 9, 10))
    assert h.filter(pl.col("cliente_id") == 2).select("vigente", "valido_hasta").row(0) == (False, date(2026, 9, 10))


def test_scd2_foto_fuera_de_orden_se_rechaza():
    h = scd.scd2(scd.scd2(None, _foto("CDMX"), date(2026, 9, 8)), _foto("Tijuana"), date(2026, 9, 12))
    with pytest.raises(scd.FotoFueraDeOrden):
        scd.scd2(h, _foto("León"), date(2026, 9, 10))


def test_scd2_el_correo_es_tipo_1():
    h = scd.scd2(scd.scd2(None, _foto("CDMX"), date(2026, 9, 8)), _foto("Tijuana", email="b@x.mx"), date(2026, 9, 12))
    assert h["email"].to_list() == ["b@x.mx", "b@x.mx"]      # se sobrescribe en todas las versiones


def test_sin_normalizar_aparecen_cambios_falsos():
    h = scd.scd2(None, _foto("CDMX"), date(2026, 9, 8))
    assert len(scd.scd2(h, _foto("cdmx "), date(2026, 9, 9))) == 2                       # "cambio" que no existe
    limpia = _foto("cdmx ").with_columns(limpieza.ciudad())
    assert len(scd.scd2(h, limpia, date(2026, 9, 9))) == 1


def test_join_por_punto_en_el_tiempo():
    h = scd.scd2(scd.scd2(None, _foto("CDMX"), date(2026, 9, 8)), _foto("Tijuana"), date(2026, 9, 12))
    p = pl.DataFrame({"pedido_id": [1, 2, 3], "cliente_id": [1, 1, 99],
                      "fecha_negocio": [date(2026, 8, 1), date(2026, 9, 13), date(2026, 9, 13)]})
    r = enriquecer.con_cliente_historico(p, h).sort("pedido_id")
    assert r["ciudad"].to_list() == ["CDMX", "Tijuana", "Desconocida"]


# ---------------------------------------------------------------- calidad
def _silver(**cambios):
    base = {"origen": ["web"] * 3, "pedido_id": [1, 2, 3], "cliente_id": [5, 6, 7], "estado": ["pagado"] * 3,
            "total": [100.0, 200.0, 300.0], "moneda": ["MXN"] * 3, "canal": ["web"] * 3,
            "creado_en": [utc(2026, 9, 1)] * 3, "actualizado_en": [utc(2026, 9, 2)] * 3, "fecha_carga": [date(2026, 9, 3)] * 3}
    base.update(cambios)
    return pl.DataFrame(base)


def test_lote_limpio_pasa_completo():
    v, q = calidad.validar(_silver())
    assert (len(v), len(q)) == (3, 0)


def test_fila_mala_va_a_cuarentena_con_su_motivo():
    v, q = calidad.validar(_silver(estado=["pagado", None, "pagado"], total=[100.0, 200.0, 999_999.0]))
    assert len(v) == 1
    assert q["motivo"].to_list() == ["estado: not_nullable", "total: less_than_or_equal_to(50000)"]


def test_falta_una_columna_detiene_todo():
    with pytest.raises(calidad.ErrorDeEsquema):
        calidad.validar(_silver().drop("moneda"))


def test_umbral_se_mide_por_carga():
    buenas = _silver(pedido_id=[1, 2, 3])
    malas = _silver(pedido_id=[4, 5, 6], fecha_carga=[date(2026, 9, 4)] * 3).with_columns(motivo=pl.lit("x"))
    r = calidad.rechazo_por_carga(buenas, malas)
    assert r["pct_rechazo"].to_list() == [0.0, 1.0]
    with pytest.raises(calidad.LoteRechazado):
        calidad.revisar_umbrales(buenas, malas, tolerancia=1e9)


# ---------------------------------------------------------------- integración: idempotencia
def test_pipeline_idempotente(tmp_path):
    from transformacion import generar_bronze, pipeline
    generar_bronze.generar(tmp_path / "landing")
    m1 = pipeline.correr(tmp_path / "landing", tmp_path / "lakehouse")
    m2 = pipeline.correr(tmp_path / "landing", tmp_path / "lakehouse")
    assert m1["huella_gold"] == m2["huella_gold"]
    assert m1["silver_pedidos"] == len(pl.read_parquet(tmp_path / "lakehouse" / "silver" / "pedidos.parquet"))


def test_pipeline_lote_malo_no_publica(tmp_path):
    from transformacion import generar_bronze, pipeline
    generar_bronze.generar(tmp_path / "landing")
    antes = pipeline.correr(tmp_path / "landing", tmp_path / "lakehouse")["huella_gold"]
    generar_bronze.generar(tmp_path / "landing", lote_malo="ruidoso")
    with pytest.raises(calidad.LoteRechazado):
        pipeline.correr(tmp_path / "landing", tmp_path / "lakehouse")
    despues = gold.huella(pl.read_parquet(tmp_path / "lakehouse" / "gold" / "ventas_diarias.parquet"))
    assert antes == despues      # falla cerrada: gold quedó como estaba
