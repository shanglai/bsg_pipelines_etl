"""Corre el proyecto dbt de punta a punta.

  python elt/correr.py                 # semillas, historia de clientes (14 fotos en orden) y dbt build
  python elt/correr.py --solo-build    # solo dbt build (lo que correría cada noche)

dbt snapshot solo conoce "el estado actual". Para reconstruir la historia de 14 días, este script aplica
las fotos una por una, en orden, como si el snapshot hubiera corrido cada noche.
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import duckdb

ELT = Path(__file__).resolve().parent
VERBOSO = False


def dbt(*args, landing):
    vars_ = {"landing": str(Path(landing).resolve().as_posix())}
    if "--vars" in args:
        i = args.index("--vars")
        vars_.update(json.loads(args[i + 1]))
        args = args[:i] + args[i + 2:]
    # dbt corre en su propio proceso: así no se queda con la base DuckDB abierta en el tuyo
    # (DuckDB no deja abrir el mismo archivo con dos configuraciones distintas a la vez).
    entorno = dict(os.environ, DBT_DUCKDB_PATH=str(ruta_bd()))
    r = subprocess.run([sys.executable, "-c", "from dbt.cli.main import cli; cli()", *args,
                        "--project-dir", str(ELT), "--profiles-dir", str(ELT), "--vars", json.dumps(vars_)],
                       capture_output=True, text=True, encoding="utf-8", env=entorno)
    r.success = r.returncode == 0
    if not r.success or VERBOSO:
        print(r.stdout[-4000:], r.stderr[-2000:], sep="\n")
    return r


def ruta_bd():
    """La base DuckDB del proyecto. Si DBT_DUCKDB_PATH es relativa, es relativa a elt/ (como en profiles.yml)."""
    ruta = Path(os.environ.get("DBT_DUCKDB_PATH", "tienda.duckdb"))
    return ruta if ruta.is_absolute() else ELT / ruta


def fechas_de_fotos(landing):
    ruta = (Path(landing) / "bronze" / "clientes" / "**" / "*.parquet").as_posix()
    filas = duckdb.sql(f"SELECT DISTINCT fecha_carga FROM read_parquet('{ruta}', hive_partitioning = true, "
                       "hive_types = {'fecha_carga': 'DATE'}) ORDER BY 1").fetchall()
    return [str(f[0]) for f in filas]


def historia(landing):
    """Reconstruye la historia: borra el snapshot y aplica cada foto del CRM en orden.
    Es el equivalente de scd.reconstruir (sesión 2.2). Un snapshot no se puede "deshacer": si ya capturó
    una foto que después se retira de bronze (un lote malo), la única salida honesta es reconstruir."""
    if ruta_bd().exists():
        with duckdb.connect(str(ruta_bd())) as c:
            c.execute("DROP TABLE IF EXISTS silver.snap_clientes")
    for fecha in fechas_de_fotos(landing):
        r = dbt("build", "-s", "stg_clientes stg_clientes_foto snap_clientes", "--vars",
                json.dumps({"fecha_foto": fecha}), landing=landing)
        if not r.success:
            raise SystemExit(f"Falló el snapshot de la foto {fecha}")
    return len(fechas_de_fotos(landing))


def main(argv=None):
    p = argparse.ArgumentParser(description="ELT con dbt sobre DuckDB")
    p.add_argument("--landing", default=str(ELT.parent / "landing"))
    p.add_argument("--solo-build", action="store_true")
    p.add_argument("--verboso", action="store_true", help="muestra la salida completa de dbt")
    a = p.parse_args(argv)
    global VERBOSO
    VERBOSO = a.verboso
    if not a.solo_build:
        dbt("seed", landing=a.landing)
        print("fotos aplicadas al snapshot:", historia(a.landing))
    r = dbt("build", landing=a.landing)
    print("dbt build:", "OK" if r.success else "FALLÓ (revisa target/run_results.json)")
    return 0 if r.success else 2


if __name__ == "__main__":
    sys.exit(main())
