-- Regla de LOTE: la mediana del total (pedidos en pesos) de cada carga contra la de todas las demás.
-- Atrapa lo posible pero falso: por ejemplo, dólares con la etiqueta MXN.
with base as (
    select fecha_carga, total from {{ ref('int_pedidos_validos') }} where moneda = 'MXN'
),
por_carga as (
    select fecha_carga, median(total) as mediana from base group by fecha_carga
)
select p.fecha_carga, p.mediana,
       (select median(b.total) from base b where b.fecha_carga <> p.fecha_carga) as referencia
from por_carga p
where p.mediana / (select median(b.total) from base b where b.fecha_carga <> p.fecha_carga) not between 1.0 / 3 and 3
