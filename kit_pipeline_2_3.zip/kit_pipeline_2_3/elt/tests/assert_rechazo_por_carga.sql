-- Regla de LOTE: ninguna carga puede tener más de var('max_rechazo') de sus pedidos en cuarentena.
-- Se mide POR CARGA: contra toda la historia, un lote roto se diluye (sesión 2.2).
with todas as (
    select fecha_carga, false as malo from {{ ref('int_pedidos_validos') }}
    union all
    select fecha_carga, true from {{ ref('int_pedidos_cuarentena') }}
)
select fecha_carga, count(*) as filas, sum(malo::int) as cuarentena,
       round(sum(malo::int) / count(*), 4) as pct_rechazo
from todas
group by fecha_carga
having sum(malo::int) / count(*) > {{ var('max_rechazo') }}
