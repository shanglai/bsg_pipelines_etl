-- dbt snapshot NO se protege de una foto vieja aplicada después de una nueva: crea versiones que terminan
-- antes de empezar. Esta prueba lo detecta (en la sesión 2.2 lo evitaba FotoFueraDeOrden).
select cliente_id, dbt_valid_from, dbt_valid_to
from {{ ref('snap_clientes') }}
where dbt_valid_to < dbt_valid_from
