{# Prueba genérica: la combinación de columnas no se repite. (dbt-utils trae una igual: unique_combination_of_columns) #}
{% test llave_unica(model, columnas) %}
select {{ columnas | join(', ') }}, count(*) as veces
from {{ model }}
group by {{ columnas | join(', ') }}
having count(*) > 1
{% endtest %}
