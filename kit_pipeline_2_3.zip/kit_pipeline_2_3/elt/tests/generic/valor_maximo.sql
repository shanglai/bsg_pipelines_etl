{# Prueba genérica: ningún valor de la columna pasa del máximo. #}
{% test valor_maximo(model, column_name, maximo) %}
select {{ column_name }} from {{ model }} where {{ column_name }} > {{ maximo }}
{% endtest %}
