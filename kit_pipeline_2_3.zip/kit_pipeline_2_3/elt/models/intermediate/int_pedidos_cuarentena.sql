-- Las filas que NO cumplen el contrato de silver, con su motivo. El equivalente en SQL de calidad.validar (sesión 2.2).
with revisado as (
    select *,
        concat_ws('; ',
            case when estado is null then 'estado: no reconocido' end,
            case when total is null then 'total: nulo' end,
            case when total <= 0 or total > 50000 then 'total: fuera de rango' end,
            case when moneda is null then 'moneda: no reconocida' end,
            case when canal not in ('web', 'app', 'tienda') then 'canal: no reconocido' end,
            case when actualizado_en < creado_en then 'actualizado_en anterior a creado_en' end
        ) as motivo
    from {{ ref('int_pedidos_unicos') }}
)
select * from revisado where motivo <> ''
