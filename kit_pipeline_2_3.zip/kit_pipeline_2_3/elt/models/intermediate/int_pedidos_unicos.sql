-- Una fila por llave de negocio (origen, pedido_id): la versión más reciente en el origen;
-- si empatan, la que se extrajo después. El mismo criterio que dedup.ultima_version (sesión 2.1).
with todos as (
    select * from {{ ref('stg_pedidos_web') }}
    union all
    select * from {{ ref('stg_pedidos_tienda') }}
)
select *
from todos
qualify row_number() over (
    partition by origen, pedido_id
    order by actualizado_en desc, _extraido_en desc
) = 1
