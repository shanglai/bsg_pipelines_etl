-- Join "as of": la última tasa publicada en o antes del día de negocio. Un inner join por fecha perdería
-- sábados, domingos y feriados (sesión 2.1).
with pedidos as (
    select *, cast(timezone('America/Mexico_City', creado_en) as date) as fecha_negocio
    from {{ ref('int_pedidos_validos') }}
)
select
    p.*,
    tc.fecha                                         as fecha_tc,
    tc.mxn_por_usd,
    date_diff('day', tc.fecha, p.fecha_negocio)      as dias_tc,
    case p.moneda when 'MXN' then p.total
                  when 'USD' then round(p.total * tc.mxn_por_usd, 2) end as total_mxn
from pedidos p
asof left join {{ ref('stg_tipo_cambio') }} tc
    on p.fecha_negocio >= tc.fecha
