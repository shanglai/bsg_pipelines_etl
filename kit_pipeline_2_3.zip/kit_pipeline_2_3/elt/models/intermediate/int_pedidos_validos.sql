select u.*
from {{ ref('int_pedidos_unicos') }} u
anti join {{ ref('int_pedidos_cuarentena') }} q using (origen, pedido_id)
