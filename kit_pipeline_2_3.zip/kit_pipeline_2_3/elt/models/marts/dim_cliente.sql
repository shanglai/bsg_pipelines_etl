-- SCD tipo 1: cómo es cada cliente HOY. Ciudad y segmento de la versión vigente del snapshot;
-- el correo (atributo tipo 1, el snapshot no lo historiza) de la foto más reciente.
select h.cliente_id, h.ciudad, h.segmento, f.email
from {{ ref('dim_cliente_historia') }} h
left join {{ ref('stg_clientes_foto') }} f using (cliente_id)
where h.vigente
