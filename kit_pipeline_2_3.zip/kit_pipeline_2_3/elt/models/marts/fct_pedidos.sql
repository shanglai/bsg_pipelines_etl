-- Cada pedido con la ciudad y el segmento del cliente EL DÍA DE LA VENTA (join por punto en el tiempo).
select
    p.origen, p.pedido_id, p.cliente_id, p.estado, p.canal, p.moneda,
    p.total, p.total_mxn, p.creado_en, p.fecha_negocio, p.fecha_tc, p.dias_tc,
    coalesce(c.ciudad, 'Desconocida')     as ciudad,
    coalesce(c.segmento, 'desconocido')   as segmento
from {{ ref('int_pedidos_en_pesos') }} p
left join {{ ref('dim_cliente_historia') }} c
       on c.cliente_id = p.cliente_id
      and p.fecha_negocio >= c.valido_desde
      and p.fecha_negocio <  c.valido_hasta
