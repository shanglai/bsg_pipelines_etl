-- La historia del snapshot, con la convención de la sesión 2.2: la primera versión vale "desde siempre".
select
    cliente_id, ciudad, segmento, email,
    case when row_number() over (partition by cliente_id order by dbt_valid_from) = 1
         then date '1900-01-01' else cast(dbt_valid_from as date) end   as valido_desde,
    cast(dbt_valid_to as date)                                          as valido_hasta,
    dbt_valid_to = timestamp '9999-12-31'                               as vigente,
    row_number() over (partition by cliente_id order by dbt_valid_from) as version
from {{ ref('snap_clientes') }}
