-- Gold solo agrega. Si aquí aparece lógica de limpieza, está en la capa equivocada.
select
    fecha_negocio, ciudad, canal,
    count(*)                                   as pedidos,
    round(sum(total_mxn), 2)                   as ingreso_mxn,
    round(sum(total_mxn) / count(*), 2)        as ticket_promedio
from {{ ref('fct_pedidos') }}
where estado <> 'cancelado'
group by all
order by all
