-- Fotos del CRM normalizadas. Se normaliza ANTES de historizar: si no, "cdmx" y "CDMX" parecen una mudanza.
select
    cast(cliente_id as bigint)                        as cliente_id,
    c.ciudad,
    lower(trim(segmento))                             as segmento,
    lower(trim(email))                                as email,
    fecha_carga
from {{ source('bronze', 'clientes') }} f
left join {{ ref('ciudades') }} c
       on c.clave = strip_accents(lower(regexp_replace(trim(f.ciudad), '\s+', ' ', 'g')))
