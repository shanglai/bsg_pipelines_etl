-- Una tasa por fecha. Si una fecha llegó en varias cargas, gana la más reciente (trae las correcciones).
select fecha, tasa as mxn_por_usd
from {{ source('bronze', 'tipo_cambio') }}
where base = 'USD' and moneda = 'MXN'
qualify row_number() over (partition by fecha order by fecha_carga desc) = 1
