-- El punto de venta: texto, hora LOCAL sin zona y folios que chocan con los id de la web.
with crudo as (
    select *,
           timezone('America/Mexico_City', strptime(fecha_hora, '%d/%m/%Y %H:%M:%S')) as momento
    from {{ source('bronze', 'pedidos_tienda') }}
)
select
    'tienda'                                                       as origen,
    cast(folio as bigint)                                          as pedido_id,
    case when trim(cliente) = '' then -1                           -- miembro desconocido: venta de mostrador
         else try_cast(cliente as bigint) end                      as cliente_id,
    e.estado,
    try_cast(regexp_replace(importe, '[$,\s]', '', 'g') as double) as total,
    m.moneda,
    'tienda'                                                       as canal,
    momento                                                        as creado_en,
    momento                                                        as actualizado_en,
    fecha_carga,
    cast(fecha_carga as timestamptz)                               as _extraido_en
from crudo c
left join {{ ref('estados_tienda') }} e on e.estatus = upper(trim(c.estatus))
left join {{ ref('monedas') }} m on m.valor = upper(trim(c.moneda))
