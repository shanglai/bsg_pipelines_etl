-- Conformar la tienda en línea al esquema de silver. Mismas reglas que limpieza.conformar_web (sesión 2.1).
select
    'web'                                                         as origen,
    id                                                            as pedido_id,
    cliente_id,
    case when lower(trim(estado)) in ('pagado', 'enviado', 'entregado', 'cancelado')
         then lower(trim(estado)) end                             as estado,      -- lo que no se reconoce queda nulo
    total,
    m.moneda,
    lower(trim(canal))                                            as canal,
    creado_en,
    actualizado_en,
    fecha_carga,
    _extraido_en
from {{ source('bronze', 'pedidos_web') }} p
left join {{ ref('monedas') }} m on m.valor = upper(trim(p.moneda))
