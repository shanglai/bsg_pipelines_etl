-- La foto que el snapshot toma como "estado actual".
-- Sin var: la foto más reciente (lo que haría la corrida de cada noche en producción).
-- Con --vars '{fecha_foto: 2026-09-10}': la foto de ese día (para reconstruir la historia en orden).
select cliente_id, ciudad, segmento, email,
       cast(fecha_carga as timestamp) as fecha_foto
from {{ ref('stg_clientes') }}
{% if var('fecha_foto', none) %}
where fecha_carga = cast('{{ var("fecha_foto") }}' as date)
{% else %}
where fecha_carga = (select max(fecha_carga) from {{ ref('stg_clientes') }})
{% endif %}
