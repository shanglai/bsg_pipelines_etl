"""Calidad de datos con Pandera: el contrato de silver, la cuarentena y los umbrales.

Tres niveles de severidad:
  esquema  falta una columna o cambió un tipo        -> se detiene TODO (no se puede confiar en nada)
  fila     un valor rompe una regla                  -> esa fila va a cuarentena, el resto sigue
  lote     demasiadas filas malas, o una distribución que no se parece a la de siempre -> se detiene la carga
"""
import pandera.polars as pa
import polars as pl

from .limpieza import ESTADOS

UTC = pl.Datetime(time_unit="us", time_zone="UTC")
TOTAL_MAXIMO = 50_000      # ningún pedido de la tienda en línea ha pasado de esta cifra


class PedidoSilver(pa.DataFrameModel):
    """El contrato de la tabla silver de pedidos. Si no lo cumple, no entra."""
    origen: str = pa.Field(isin=["web", "tienda"])
    pedido_id: int = pa.Field(gt=0)
    cliente_id: int
    estado: str = pa.Field(isin=ESTADOS)                 # no nulo por omisión: un estado desconocido no pasa
    total: float = pa.Field(gt=0, le=TOTAL_MAXIMO)
    moneda: str = pa.Field(isin=["MXN", "USD"])
    canal: str = pa.Field(isin=["web", "app", "tienda"])
    creado_en: UTC
    actualizado_en: UTC

    class Config:
        strict = False          # se permiten columnas adicionales (metadatos de la ingesta)

    @pa.dataframe_check(error="llave (origen, pedido_id) duplicada")
    def llave_unica(cls, data: pa.PolarsData) -> pl.LazyFrame:
        return data.lazyframe.select(pl.struct("origen", "pedido_id").is_duplicated().not_())

    @pa.dataframe_check(error="actualizado_en anterior a creado_en")
    def orden_temporal(cls, data: pa.PolarsData) -> pl.LazyFrame:
        return data.lazyframe.select(pl.col("actualizado_en") >= pl.col("creado_en"))


class ErrorDeEsquema(Exception):
    """El lote no tiene la forma esperada: no se procesa nada."""

    def __init__(self, fallas):
        self.fallas = fallas
        super().__init__("Falla de esquema: " + "; ".join(f"{r['column']}: {r['check']}" for r in fallas.iter_rows(named=True)))


class LoteRechazado(Exception):
    """Una o más cargas no pasaron los umbrales: no se publica nada."""

    def __init__(self, motivos):
        self.motivos = motivos
        super().__init__("Lote rechazado: " + "; ".join(motivos))


def validar(df, modelo=PedidoSilver):
    """Devuelve (filas válidas, cuarentena con su motivo). Lanza ErrorDeEsquema si la forma está mal."""
    try:
        modelo.validate(df, lazy=True)
        return df, df.clear().with_columns(motivo=pl.lit(None, pl.String))
    except pa.errors.SchemaErrors as e:
        fallas = e.failure_cases
    de_esquema = fallas.filter(pl.col("index").is_null())
    if len(de_esquema):
        raise ErrorDeEsquema(de_esquema)
    regla = pl.when(pl.col("schema_context") == "DataFrameSchema").then(pl.col("check")) \
              .otherwise(pl.concat_str(pl.col("column"), pl.lit(": "), pl.col("check")))
    motivos = (fallas.with_columns(regla=regla, index=pl.col("index").cast(pl.UInt32))
               .group_by("index").agg(motivo=pl.col("regla").unique().sort().str.join("; ")))
    con_fila = df.with_row_index("_fila")
    cuarentena = con_fila.join(motivos, left_on="_fila", right_on="index").drop("_fila")
    validas = con_fila.join(motivos, left_on="_fila", right_on="index", how="anti").drop("_fila")
    return validas, cuarentena


def por_regla(cuarentena):
    return (cuarentena.with_columns(pl.col("motivo").str.split("; ")).explode("motivo")
            .group_by("motivo").len().sort("len", descending=True).rename({"len": "filas"}))


def rechazo_por_carga(validas, cuarentena):
    """El umbral se mide POR CARGA: contra toda la historia, un lote roto se diluye y pasa desapercibido."""
    todas = pl.concat([validas.select("fecha_carga", malo=pl.lit(False)), cuarentena.select("fecha_carga", malo=pl.lit(True))])
    return (todas.group_by("fecha_carga").agg(filas=pl.len(), cuarentena=pl.col("malo").sum())
            .with_columns(pct_rechazo=(pl.col("cuarentena") / pl.col("filas")).round(4)).sort("fecha_carga"))


def distribucion_por_carga(validas, columna="total", tolerancia=3.0):
    """Regla de LOTE: la mediana de cada carga contra la mediana de todas las demás.
    Detecta lo que ninguna regla por fila ve (por ejemplo, dólares que llegan con la etiqueta de pesos)."""
    base = validas.filter(pl.col("moneda") == "MXN")
    medianas = base.group_by("fecha_carga").agg(mediana=pl.col(columna).median(), filas=pl.len()).sort("fecha_carga")
    referencia = []
    for f in medianas["fecha_carga"]:
        referencia.append(base.filter(pl.col("fecha_carga") != f)[columna].median())
    return medianas.with_columns(referencia=pl.Series(referencia)).with_columns(
        razon=(pl.col("mediana") / pl.col("referencia")).round(2)).with_columns(
        sospechosa=(pl.col("razon") > tolerancia) | (pl.col("razon") < 1 / tolerancia))


def revisar_umbrales(validas, cuarentena, max_rechazo=0.02, tolerancia=3.0):
    motivos = []
    for r in rechazo_por_carga(validas, cuarentena).filter(pl.col("pct_rechazo") > max_rechazo).iter_rows(named=True):
        motivos.append(f"carga {r['fecha_carga']}: {r['pct_rechazo']:.1%} en cuarentena (máximo {max_rechazo:.0%})")
    for r in distribucion_por_carga(validas, tolerancia=tolerancia).filter("sospechosa").iter_rows(named=True):
        motivos.append(f"carga {r['fecha_carga']}: mediana del total {r['razon']}x la de siempre")
    if motivos:
        raise LoteRechazado(motivos)
