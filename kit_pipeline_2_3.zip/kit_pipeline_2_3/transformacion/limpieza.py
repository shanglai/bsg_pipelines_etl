"""Limpieza y conformado: llevar cada fuente al MISMO esquema de silver.

Regla de diseño: cada función recibe un DataFrame (o una expresión) y devuelve otro. No lee archivos,
no escribe archivos, no consulta la hora del sistema. Por eso se puede probar con tres filas hechas a mano.
"""
import polars as pl

ZONA_NEGOCIO = "America/Mexico_City"
ESTADOS = ["pagado", "enviado", "entregado", "cancelado"]
MONEDAS = {"MXN": "MXN", "MN": "MXN", "M.N.": "MXN", "PESOS": "MXN", "USD": "USD", "US$": "USD", "DLS": "USD"}
ESTATUS_TIENDA = {"VENTA": "entregado", "CANCELADA": "cancelado"}
CIUDADES = ["CDMX", "Guadalajara", "Monterrey", "Puebla", "Querétaro", "Mérida", "Toluca", "León", "Tijuana", "Cancún"]
ALIAS_CIUDAD = {"ciudad de mexico": "CDMX", "cd. de mexico": "CDMX", "cd de mexico": "CDMX", "df": "CDMX"}
SEGMENTOS = ["nuevo", "frecuente", "vip"]
CLIENTE_DESCONOCIDO = -1        # "miembro desconocido": ventas de mostrador sin cliente

# Esquema de silver: el contrato que todas las fuentes deben cumplir al salir de aquí
ESQUEMA_PEDIDOS = {
    "origen": pl.String, "pedido_id": pl.Int64, "cliente_id": pl.Int64, "estado": pl.String,
    "total": pl.Float64, "moneda": pl.String, "canal": pl.String,
    "creado_en": pl.Datetime("us", "UTC"), "actualizado_en": pl.Datetime("us", "UTC"),
    "fecha_carga": pl.Date, "_extraido_en": pl.Datetime("us", "UTC"),
}


# ---------- expresiones reutilizables
def texto(col):
    """Quita espacios a los lados y colapsa los de en medio."""
    return pl.col(col).str.strip_chars().str.replace_all(r"\s+", " ")


def clave(col):
    """Forma canónica para comparar textos: minúsculas, sin acentos, sin espacios sobrantes."""
    return texto(col).str.to_lowercase().str.normalize("NFKD").str.replace_all(r"\p{M}", "")


def estado(col="estado"):
    """'PAGADO ', 'Pagado' y ' pagado' son lo mismo. Lo que no se reconoce queda NULO (no se inventa)."""
    limpio = texto(col).str.to_lowercase()
    return pl.when(limpio.is_in(ESTADOS)).then(limpio).otherwise(None)


def moneda(col="moneda"):
    return texto(col).str.to_uppercase().replace_strict(MONEDAS, default=None)


def ciudad(col="ciudad"):
    mapa = {**{c.lower().translate(str.maketrans("áéíóú", "aeiou")): c for c in CIUDADES}, **ALIAS_CIUDAD}
    return clave(col).replace_strict(mapa, default=None)


def importe(col):
    """'$1,234.50' -> 1234.5  (el punto de venta manda texto con formato de moneda)."""
    return pl.col(col).str.replace_all(r"[$,\s]", "").cast(pl.Float64, strict=False)


# ---------- conformar cada fuente al esquema de silver
def conformar_web(df):
    return df.select(
        origen=pl.lit("web"),
        pedido_id=pl.col("id"),
        cliente_id=pl.col("cliente_id"),
        estado=estado("estado"),
        total=pl.col("total"),
        moneda=moneda("moneda"),
        canal=texto("canal").str.to_lowercase(),
        creado_en=pl.col("creado_en"),
        actualizado_en=pl.col("actualizado_en"),
        fecha_carga=pl.col("fecha_carga"),
        _extraido_en=pl.col("_extraido_en"),
    ).cast(ESQUEMA_PEDIDOS)


def conformar_tienda(df):
    """El punto de venta: todo es texto, la hora es LOCAL sin zona y el folio choca con los id de la web."""
    momento = (pl.col("fecha_hora").str.to_datetime("%d/%m/%Y %H:%M:%S", time_unit="us")
               .dt.replace_time_zone(ZONA_NEGOCIO).dt.convert_time_zone("UTC"))
    return df.select(
        origen=pl.lit("tienda"),
        pedido_id=pl.col("folio").cast(pl.Int64),
        cliente_id=pl.when(texto("cliente") == "").then(CLIENTE_DESCONOCIDO)
                     .otherwise(pl.col("cliente").cast(pl.Int64, strict=False)),
        estado=texto("estatus").str.to_uppercase().replace_strict(ESTATUS_TIENDA, default=None),
        total=importe("importe"),
        moneda=moneda("moneda"),
        canal=pl.lit("tienda"),
        creado_en=momento,
        actualizado_en=momento,
        fecha_carga=pl.col("fecha_carga"),
        _extraido_en=pl.col("fecha_carga").cast(pl.Datetime("us", "UTC")),
    ).cast(ESQUEMA_PEDIDOS)


def pedidos(web, tienda):
    """Une ambas fuentes ya conformadas. La llave de negocio es (origen, pedido_id): el folio 1 existe en las dos."""
    return pl.concat([conformar_web(web), conformar_tienda(tienda)], how="vertical")


def fecha_negocio(col="creado_en"):
    """El día en que ocurrió la venta EN MÉXICO. Un pedido de las 21:00 en CDMX ya es el día siguiente en UTC."""
    return pl.col(col).dt.convert_time_zone(ZONA_NEGOCIO).dt.date()


def clientes(df):
    return df.select(
        cliente_id=pl.col("cliente_id").cast(pl.Int64),
        ciudad=ciudad("ciudad"),
        segmento=texto("segmento").str.to_lowercase(),
        email=texto("email").str.to_lowercase(),
        fecha_carga=pl.col("fecha_carga"),
    )
