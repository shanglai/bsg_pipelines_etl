"""Lectura de bronze. Es la ÚNICA parte de la transformación que sabe dónde viven los archivos."""
from pathlib import Path

import polars as pl

TABLAS = ("pedidos_web", "pedidos_tienda", "clientes", "tipo_cambio")


def bronze(landing, tabla, hasta=None):
    """LazyFrame con todas las cargas de una tabla; la partición fecha_carga=... se vuelve columna."""
    ruta = Path(landing) / "bronze" / tabla / "**" / "*.parquet"
    lf = pl.scan_parquet(ruta, hive_partitioning=True, hive_schema={"fecha_carga": pl.Date})
    if hasta is not None:
        lf = lf.filter(pl.col("fecha_carga") <= pl.lit(hasta).cast(pl.Date))
    return lf


def todas(landing, hasta=None):
    return {t: bronze(landing, t, hasta).collect() for t in TABLAS}
