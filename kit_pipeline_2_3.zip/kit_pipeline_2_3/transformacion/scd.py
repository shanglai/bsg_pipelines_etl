"""Dimensiones lentamente cambiantes (SCD) a partir de fotos completas diarias del CRM.

Tipo 1: sobrescribir. La dimensión dice cómo es el cliente HOY; la historia se pierde.
Tipo 2: versionar. Cada cambio cierra la versión vigente y abre una nueva con su rango de validez.
Híbrida (lo normal en la vida real): ciudad y segmento son tipo 2; el correo es tipo 1.
"""
from datetime import date

import polars as pl

INICIO = date(1900, 1, 1)      # la primera versión de cada cliente vale "desde siempre"
FIN = date(9999, 12, 31)       # una versión vigente vale "hasta nuevo aviso"
LLAVE = "cliente_id"
TIPO_2 = ["ciudad", "segmento"]
TIPO_1 = ["email"]


class FotoFueraDeOrden(Exception):
    """Aplicar una foto vieja después de una nueva reescribiría la historia al revés."""


def scd1(actual, foto):
    """Sobrescribe con la foto. Los clientes que ya no vienen se marcan inactivos (no se borran)."""
    nueva = foto.select(LLAVE, *TIPO_2, *TIPO_1).with_columns(activo=pl.lit(True))
    if actual is None:
        return nueva.sort(LLAVE)
    bajas = actual.join(nueva, on=LLAVE, how="anti").with_columns(activo=pl.lit(False))
    return pl.concat([nueva, bajas.select(nueva.columns)]).sort(LLAVE)


def scd2(historia, foto, fecha):
    """Aplica la foto del día `fecha` sobre la historia. Aplicar dos veces la misma foto no cambia nada."""
    foto = foto.select(LLAVE, *TIPO_2, *TIPO_1)
    columnas = [LLAVE, *TIPO_2, *TIPO_1, "valido_desde", "valido_hasta", "vigente", "version"]
    if historia is None or historia.is_empty():
        return foto.with_columns(valido_desde=pl.lit(INICIO), valido_hasta=pl.lit(FIN),
                                 vigente=pl.lit(True), version=pl.lit(1, pl.Int32)).select(columnas).sort(LLAVE)

    vigentes = historia.filter("vigente")
    cruce = vigentes.join(foto, on=LLAVE, how="inner", suffix="_foto")
    distinto = pl.any_horizontal([pl.col(c).ne_missing(pl.col(f"{c}_foto")) for c in TIPO_2])
    cambiados = cruce.filter(distinto)[LLAVE]
    bajas = vigentes.join(foto, on=LLAVE, how="anti")[LLAVE]
    nuevos = foto.join(vigentes, on=LLAVE, how="anti")[LLAVE]          # incluye clientes que regresan

    hay_cambios = len(cambiados) + len(bajas) + len(nuevos) > 0
    ultima = historia["valido_desde"].max()
    if hay_cambios and fecha <= ultima:
        raise FotoFueraDeOrden(f"La historia ya tiene versiones del {ultima}; la foto del {fecha} llega tarde. "
                               "Reconstruye la dimensión desde todas las fotos en orden.")

    cerrar = pl.col(LLAVE).is_in(pl.concat([cambiados, bajas]).implode()) & pl.col("vigente")
    historia = historia.with_columns(valido_hasta=pl.when(cerrar).then(pl.lit(fecha)).otherwise("valido_hasta"),
                                     vigente=pl.when(cerrar).then(False).otherwise("vigente"))

    version_previa = historia.group_by(LLAVE).agg(pl.col("version").max().alias("previa"))
    abiertas = (foto.filter(pl.col(LLAVE).is_in(pl.concat([cambiados, nuevos]).implode()))
                .join(version_previa, on=LLAVE, how="left")
                .with_columns(version=(pl.col("previa").fill_null(0) + 1).cast(pl.Int32))
                .with_columns(valido_desde=pl.when(pl.col("version") == 1).then(pl.lit(INICIO)).otherwise(pl.lit(fecha)),
                              valido_hasta=pl.lit(FIN), vigente=pl.lit(True))
                .select(columnas))

    # Atributos tipo 1: el correo se sobrescribe en TODAS las versiones del cliente
    historia = (historia.join(foto.select(LLAVE, *[pl.col(c).alias(f"{c}_foto") for c in TIPO_1]), on=LLAVE, how="left")
                .with_columns([pl.coalesce(f"{c}_foto", c).alias(c) for c in TIPO_1]).select(columnas))
    return pl.concat([historia, abiertas]).sort(LLAVE, "valido_desde")


def reconstruir(fotos):
    """La dimensión completa a partir de TODAS las fotos, en orden. Lento con años de fotos, pero siempre correcto."""
    historia = None
    for (fecha,), foto in fotos.sort("fecha_carga").group_by("fecha_carga", maintain_order=True):
        historia = scd2(historia, foto, fecha)
    return historia


def historia_de(historia, cliente_id):
    return historia.filter(pl.col(LLAVE) == cliente_id).sort("version")
