"""Genera la capa bronze de la tienda: 14 días de cargas, con las mañas típicas de los sistemas reales.

Uso local:  python -m transformacion.generar_bronze --landing landing
            python -m transformacion.generar_bronze --landing landing --lote-malo ruidoso      (agrega la carga rota del 22/09)
            python -m transformacion.generar_bronze --landing landing --lote-malo silencioso   (otra rotura, más difícil de ver)

Escribe en <landing>/bronze/:
  pedidos_web/fecha_carga=AAAA-MM-DD/*.parquet     extracción incremental de la base de la tienda en línea
  pedidos_tienda/fecha_carga=AAAA-MM-DD/*.parquet  exportación del punto de venta (todo llega como texto)
  clientes/fecha_carga=AAAA-MM-DD/clientes.parquet foto completa diaria del CRM
  tipo_cambio/fecha_carga=AAAA-MM-DD/*.parquet     API de tipo de cambio (ventana de los últimos días)

Las mañas, a propósito:
  pedidos_web     versiones repetidas por el traslape de 1 h, una carga escrita dos veces por un reintento,
                  estados y monedas escritos de varias formas, algunos totales nulos y clientes que no existen,
                  6 pedidos corregidos a mano por soporte sin mover actualizado_en (empate de versiones)
  pedidos_tienda  folios que chocan con los id de la web, importes "$1,234.50", fecha local sin zona,
                  ventas de mostrador sin cliente, un archivo reenviado dos días después
  clientes        la misma ciudad escrita de 5 formas, cambios de ciudad y segmento, un cambio que se revierte,
                  bajas y altas, correos que cambian
  tipo_cambio     solo días hábiles (sin fines de semana ni el 16 de septiembre), ventanas que se traslapan
                  y una corrección del publicador
"""
import argparse
import shutil
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import polars as pl

SEMILLA = 987654
INICIO_HISTORIA = date(2026, 6, 10)
PRIMERA_CARGA = date(2026, 9, 8)
ULTIMA_CARGA = date(2026, 9, 21)
CARGA_MALA = date(2026, 9, 22)
UTC_MENOS_6 = timedelta(hours=6)          # CDMX no tiene horario de verano desde 2022
TRASLAPE = timedelta(hours=1)             # ventana de traslape de la extracción incremental

CIUDADES = ["CDMX", "Guadalajara", "Monterrey", "Puebla", "Querétaro", "Mérida", "Toluca", "León", "Tijuana", "Cancún"]
PESO_CIUDAD = [.30, .14, .13, .08, .07, .06, .06, .06, .05, .05]
VARIANTES = {"CDMX": ["Ciudad de México", "cdmx", "CDMX ", "Cd. de México", "CIUDAD DE MEXICO"]}
SEGMENTOS = ["nuevo", "frecuente", "vip"]
SUCURSALES = ["CDMX-Centro", "GDL-Chapultepec", "MTY-San Pedro"]
FERIADOS = {date(2026, 9, 16)}


def _variante(rng, ciudad):
    """La misma ciudad, escrita como la capturó cada persona."""
    if ciudad in VARIANTES:
        return VARIANTES[ciudad][rng.integers(len(VARIANTES[ciudad]))]
    sin_acento = ciudad.translate(str.maketrans("áéíóú", "aeiou"))
    return [ciudad.lower(), ciudad.upper(), ciudad + " ", sin_acento][rng.integers(4)]


def _local_a_utc(d, segundos):
    return datetime(d.year, d.month, d.day, tzinfo=timezone.utc) + timedelta(seconds=int(segundos)) + UTC_MENOS_6


def _extraccion(d):
    """Momento de la extracción de la carga d: 03:00 hora de CDMX."""
    return datetime(d.year, d.month, d.day, 3, tzinfo=timezone.utc) + UTC_MENOS_6


def simular(semilla=SEMILLA, hasta=CARGA_MALA):
    rng = np.random.default_rng(semilla)

    # ---------- clientes: estado inicial y una bitácora de cambios por día
    clientes = {i: {"ciudad": CIUDADES[rng.choice(len(CIUDADES), p=PESO_CIUDAD)],
                    "segmento": SEGMENTOS[rng.choice(3, p=[.6, .32, .08])],
                    "email": f"cliente{i}@correo.mx"} for i in range(1, 2001)}
    fotos = {}                       # fecha de carga -> copia del estado (foto del CRM al cierre del día anterior)
    siguiente_cliente = 2001
    revertido = {}                   # cliente -> (día en que regresa, ciudad original)

    # ---------- pedidos web: cada pedido nace con su ciclo de vida completo [(estado, momento)]
    pedidos = {}
    siguiente_pedido = 1
    ventas_tienda = []               # (folio, sucursal, cliente, momento, importe, moneda, estatus, día)
    folio = 1
    activos = list(clientes)

    d = INICIO_HISTORIA
    while d < hasta:
        # Cambios en clientes (solo importan los que ocurren a partir de la primera foto)
        if d >= PRIMERA_CARGA:
            for cid in rng.choice(activos, 16, replace=False):
                clientes[int(cid)]["ciudad"] = CIUDADES[rng.integers(len(CIUDADES))]
            for cid in rng.choice(activos, 10, replace=False):
                clientes[int(cid)]["segmento"] = SEGMENTOS[rng.integers(3)]
            for cid in rng.choice(activos, 3, replace=False):
                clientes[int(cid)]["email"] = f"c{int(cid)}.{d:%m%d}@otrocorreo.com"
            for _ in range(5):
                clientes[siguiente_cliente] = {"ciudad": CIUDADES[rng.choice(len(CIUDADES), p=PESO_CIUDAD)],
                                               "segmento": "nuevo", "email": f"cliente{siguiente_cliente}@correo.mx"}
                activos.append(siguiente_cliente)
                siguiente_cliente += 1
            if d in (date(2026, 9, 10), date(2026, 9, 14), date(2026, 9, 18)):      # bajas
                baja = int(rng.choice(activos[:2000]))
                activos.remove(baja)
                clientes.pop(baja)
            if d == date(2026, 9, 11):        # un cambio que se revierte tres días después
                cid = 42 if 42 in clientes else activos[0]
                revertido[cid] = (date(2026, 9, 14), clientes[cid]["ciudad"])
                clientes[cid]["ciudad"] = "Tijuana" if clientes[cid]["ciudad"] != "Tijuana" else "Mérida"
            for cid, (dia, ciudad) in list(revertido.items()):
                if d == dia and cid in clientes:
                    clientes[cid]["ciudad"] = ciudad

        # Pedidos web del día
        for _ in range(rng.poisson(230)):
            nace = _local_a_utc(d, rng.integers(0, 86_400))
            usd = rng.random() < 0.10
            total = float(np.round(rng.lognormal(6.6, 0.7) / (18.5 if usd else 1), 2))
            vida = [("pagado", nace)]
            if rng.random() < 0.05:
                vida.append(("cancelado", nace + timedelta(hours=float(rng.uniform(1, 20)))))
            else:
                enviado = nace + timedelta(hours=float(rng.uniform(12, 48)))
                vida += [("enviado", enviado), ("entregado", enviado + timedelta(hours=float(rng.uniform(30, 96))))]
            cliente = int(rng.choice(activos)) if rng.random() > 0.003 else int(90_000 + rng.integers(1000))
            pedidos[siguiente_pedido] = {"cliente_id": cliente, "total": total, "moneda": "USD" if usd else "MXN",
                                         "canal": "app" if rng.random() < 0.4 else "web", "vida": vida}
            siguiente_pedido += 1

        # Ventas de mostrador del día (punto de venta)
        for suc in SUCURSALES:
            for _ in range(rng.poisson(20)):
                momento = d.strftime("%d/%m/%Y") + " " + str(timedelta(seconds=int(rng.integers(9 * 3600, 21 * 3600)))).zfill(8)
                cliente = "" if rng.random() < 0.45 else str(int(rng.choice(activos)))
                usd = rng.random() < 0.04
                importe = float(np.round(rng.lognormal(6.2, 0.6) / (18.5 if usd else 1), 2))
                ventas_tienda.append({"folio": str(folio), "sucursal": suc, "cliente": cliente, "fecha_hora": momento,
                                      "importe": f"${importe:,.2f}", "moneda": "USD" if usd else "MN",
                                      "estatus": "CANCELADA" if rng.random() < 0.03 else "VENTA", "dia": d})
                folio += 1

        d += timedelta(days=1)
        if d >= PRIMERA_CARGA:
            fotos[d] = {k: dict(v) for k, v in clientes.items()}

    # ---------- tipo de cambio: días hábiles, caminata aleatoria
    tc, nivel, d = {}, 18.60, date(2026, 6, 1)
    while d < hasta:
        if d.weekday() < 5 and d not in FERIADOS:
            nivel = round(nivel + float(rng.normal(0, 0.06)), 4)
            tc[d] = nivel
        d += timedelta(days=1)
    return {"pedidos": pedidos, "tienda": ventas_tienda, "fotos": fotos, "tc": tc, "rng": rng}


def _estado_en(vida, momento):
    actual = None
    for estado, t in vida:
        if t <= momento:
            actual = (estado, t)
    return actual


def _ensuciar_estado(rng, estado):
    if rng.random() < 0.03:
        return [estado.capitalize(), estado.upper(), " " + estado, estado + " "][rng.integers(4)]
    return estado


def _ensuciar_moneda(rng, moneda):
    r = rng.random()
    if moneda == "MXN" and r < 0.015:
        return "mxn"
    if moneda == "MXN" and r < 0.025:
        return "MN"
    if moneda == "USD" and r < 0.03:
        return " USD"
    return moneda


def _escribir(df, ruta):
    ruta.parent.mkdir(parents=True, exist_ok=True)
    df.write_parquet(ruta)


def _filas_web(sim, desde, hasta, rng, malo=False):
    filas = []
    for pid, p in sim["pedidos"].items():
        if p["vida"][0][1] > hasta:
            continue
        estado, t = _estado_en(p["vida"], hasta)
        if desde is not None and not (desde < t <= hasta):
            continue
        total = None if rng.random() < 0.002 else p["total"]
        moneda = _ensuciar_moneda(rng, p["moneda"])
        estado = _ensuciar_estado(rng, estado)
        if malo == "silencioso":
            if total is not None and p["moneda"] == "MXN":
                total = round(total / 18.5, 2)             # el origen mandó dólares... con la etiqueta MXN
        elif malo:
            if total is not None and rng.random() < 0.35:
                total = round(total * 100, 2)              # el sistema de origen empezó a mandar centavos
            if rng.random() < 0.05:
                estado = "pagado_pendiente"                # un estado nuevo que nadie avisó
            if rng.random() < 0.04:
                moneda = None
        filas.append({"id": pid, "cliente_id": p["cliente_id"], "estado": estado, "total": total, "moneda": moneda,
                      "canal": p["canal"], "creado_en": p["vida"][0][1], "actualizado_en": t, "_extraido_en": hasta})
    esquema = {"id": pl.Int64, "cliente_id": pl.Int64, "estado": pl.String, "total": pl.Float64, "moneda": pl.String,
               "canal": pl.String, "creado_en": pl.Datetime("us", "UTC"), "actualizado_en": pl.Datetime("us", "UTC"),
               "_extraido_en": pl.Datetime("us", "UTC")}   # metadato que agrega la ingesta
    return pl.DataFrame(filas, schema=esquema, orient="row") if filas else pl.DataFrame(schema=esquema)


def _foto_clientes(sim, carga, rng):
    filas = []
    for cid, c in sorted(sim["fotos"][carga].items()):
        ciudad = _variante(rng, c["ciudad"]) if rng.random() < 0.06 else c["ciudad"]
        segmento = c["segmento"].capitalize() if rng.random() < 0.03 else c["segmento"]
        email = c["email"].upper() if rng.random() < 0.02 else c["email"]
        filas.append({"cliente_id": cid, "ciudad": ciudad, "segmento": segmento, "email": email})
    return pl.DataFrame(filas)


def _tienda(sim, dias):
    filas = [{k: v for k, v in f.items() if k != "dia"} for f in sim["tienda"] if f["dia"] in dias]
    return pl.DataFrame(filas, schema={c: pl.String for c in ["folio", "sucursal", "cliente", "fecha_hora", "importe", "moneda", "estatus"]})


def _tc(sim, desde, hasta):
    filas = [{"fecha": d, "base": "USD", "moneda": "MXN", "tasa": v} for d, v in sorted(sim["tc"].items()) if desde <= d < hasta]
    return pl.DataFrame(filas)


def generar(landing, lote_malo=None, semilla=SEMILLA):
    """lote_malo: None (solo las 14 cargas buenas), "ruidoso" o "silencioso" (agrega la carga del 22/09)."""
    landing = Path(landing)
    bronze = landing / "bronze"
    for t in ("pedidos_web", "pedidos_tienda", "clientes", "tipo_cambio"):
        shutil.rmtree(bronze / t, ignore_errors=True)
    sim = simular(semilla)
    rng = np.random.default_rng(semilla + 1)
    marca = None
    cargas = []
    carga = PRIMERA_CARGA
    ultimo = CARGA_MALA if lote_malo else ULTIMA_CARGA
    while carga <= ultimo:
        part = f"fecha_carga={carga.isoformat()}"
        corte = _extraccion(carga)
        malo = lote_malo if carga == CARGA_MALA else None
        # pedidos web: primera carga completa; después incremental con traslape
        web = _filas_web(sim, None if marca is None else marca - TRASLAPE, corte, rng, malo=malo)
        _escribir(web, bronze / "pedidos_web" / part / "parte-0.parquet")
        if carga == date(2026, 9, 12):          # el orquestador reintentó y la primera escritura sí había llegado
            _escribir(web, bronze / "pedidos_web" / part / "parte-0-reintento.parquet")
        if carga == date(2026, 9, 17):          # soporte corrigió 6 pedidos a mano sin mover actualizado_en
            ids = sorted(sim["pedidos"])[-3000:-2994]
            antes = _filas_web(sim, None, corte, np.random.default_rng(0)).filter(pl.col("id").is_in(ids))
            corregidos = antes.with_columns(estado=pl.lit("cancelado"), _extraido_en=pl.lit(corte + timedelta(hours=2)))
            _escribir(corregidos, bronze / "pedidos_web" / part / "reproceso-soporte.parquet")
            for i in ids:     # el origen ya dice "cancelado" con la misma marca de tiempo
                vida = sim["pedidos"][i]["vida"]
                estado, t = _estado_en(vida, corte)
                sim["pedidos"][i]["vida"] = [v for v in vida if v[1] < t] + [("cancelado", t)]
        if len(web):
            marca = web["actualizado_en"].max()
        # punto de venta: la primera carga trae toda la historia; después, el día anterior
        if carga == PRIMERA_CARGA:
            dias = {INICIO_HISTORIA + timedelta(days=i) for i in range((carga - INICIO_HISTORIA).days)}
        else:
            dias = {carga - timedelta(days=1)}
        for suc in SUCURSALES:
            df = _tienda(sim, dias).filter(pl.col("sucursal") == suc)
            _escribir(df, bronze / "pedidos_tienda" / part / f"{suc}.parquet")
        if carga == date(2026, 9, 15):          # el punto de venta reenvió las ventas del 13
            _escribir(_tienda(sim, {date(2026, 9, 13)}), bronze / "pedidos_tienda" / part / "reenvio-0913.parquet")
        # clientes: foto completa
        _escribir(_foto_clientes(sim, carga, rng), bronze / "clientes" / part / "clientes.parquet")
        # tipo de cambio: la primera trae la historia, después una ventana de 7 días
        desde_tc = date(2026, 6, 1) if carga == PRIMERA_CARGA else carga - timedelta(days=7)
        if carga == date(2026, 9, 14):          # el publicador corrigió el dato del 11; de aquí en adelante viene corregido
            sim["tc"][date(2026, 9, 11)] = round(sim["tc"][date(2026, 9, 11)] + 0.05, 4)
        _escribir(_tc(sim, desde_tc, carga), bronze / "tipo_cambio" / part / "tipo_cambio.parquet")
        cargas.append(carga)
        carga += timedelta(days=1)
    return {"cargas": len(cargas), "desde": cargas[0].isoformat(), "hasta": cargas[-1].isoformat(),
            "pedidos_web_bronze": pl.scan_parquet(bronze / "pedidos_web" / "**" / "*.parquet").select(pl.len()).collect().item(),
            "pedidos_tienda_bronze": pl.scan_parquet(bronze / "pedidos_tienda" / "**" / "*.parquet").select(pl.len()).collect().item(),
            "clientes_ultima_foto": len(_foto_clientes(sim, cargas[-1], np.random.default_rng(1)))}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Genera la capa bronze de la tienda")
    p.add_argument("--landing", default="landing")
    p.add_argument("--lote-malo", choices=["ruidoso", "silencioso"], help="agrega la carga del 22/09 con datos rotos (sesión 2.2)")
    a = p.parse_args()
    print(generar(a.landing, a.lote_malo))
