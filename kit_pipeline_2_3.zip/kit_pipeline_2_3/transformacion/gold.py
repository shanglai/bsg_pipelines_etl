"""Gold: tablas listas para el tablero. Solo agrega; toda la lógica de limpieza ya ocurrió en silver."""
import hashlib

import polars as pl


def ventas_diarias(pedidos):
    return (pedidos.filter(pl.col("estado") != "cancelado")
            .group_by("fecha_negocio", "ciudad", "canal")
            .agg(pedidos=pl.len(), ingreso_mxn=pl.col("total_mxn").sum().round(2))
            .with_columns(ticket_promedio=(pl.col("ingreso_mxn") / pl.col("pedidos")).round(2))
            .sort("fecha_negocio", "ciudad", "canal"))


def ventas_por_ciudad(pedidos, desde=None):
    p = pedidos.filter(pl.col("estado") != "cancelado")
    if desde is not None:
        p = p.filter(pl.col("fecha_negocio") >= desde)
    return p.group_by("ciudad").agg(pedidos=pl.len(), ingreso_mxn=pl.col("total_mxn").sum().round(2)).sort("ingreso_mxn", descending=True)


def huella(df):
    """Una huella del contenido: si correr el pipeline dos veces da la misma huella, es idempotente."""
    return hashlib.sha256(df.sort(df.columns).write_csv().encode()).hexdigest()[:16]
